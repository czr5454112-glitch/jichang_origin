# G31 有限托盘 ICS 阶段审阅与下一阶段 Learning 实施任务

> 审阅日期：2026-10-17。固定提交：`da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a`。研究分支：`codex/g31-ics-v3-circulation`。
>
> **审阅结论：保留当前底座，进入下一阶段。L0 学习已经开始；下一批工作应完成真实后续观察—动作—执行的连接，并立即在合格小域中进行多步 learning。当前尚不能验收为完整多步 RL、机场规模有限托盘系统、100 ms 实时系统，或已经证明论文方法创新。**

本文件记录可公开复核的判断依据、实测与未测边界、近邻文献、反例和具体实施任务。它是对 `G31_ICS_CODEX_FOUNDATION_LEARNING_20261017.md` 的阶段补充：已完成部分不重新立项；与本文件冲突的就绪状态、创新性措辞和近期文献状态以本次审阅为准。原研究目标、R1/R2 要求及逐件保护要求继续保留。

## 0. 给 Codex 的开工指令

沿用上述研究分支和已验收的原生核心，不另造物理仿真器，不合并 main。本轮只安排第 7 节的三项主任务：

1. **接通真实后续 v3 观察、当前候选和原生动作入口。**从已经存在的 `first_reuse_route` 切点开始，同一实现再覆盖 `first_return`；验证真实动作效果及下一次状态转移。
2. **先过滤公开不兼容候选，再分配推演预算。**补齐兼容 8 项穷举强基线，计入共享前缀成本，修正现有 parity 比较器的类型漏检。
3. **用新闭环轨迹真正训练一个小策略，并验证服务依赖驱动的更新方法。**先完成可运行的多步 learning，再扩大原地图负载；不把三场景内反复换网络当作贡献。

任务 1 是新多步 learning 的实际接口依赖；任务 2 可与它并行。任务 1 的明确小域通过后，即可开展任务 3 的首次训练，不等待全部故障、全天负载或最终 100 ms 认证。若只能激活 retained policy，`train-rl` 必须继续明确返回未就绪，不能把状态标签改成已完成。

## 1. 审阅对象与独立复核口径

### 1.1 固定版本

- [GitHub 固定提交](https://github.com/czr5454112-glitch/jichang_origin/commit/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a)。该提交主要修订审阅包的字节与换行处理；算法及证据提交为其父提交 `b973ad23e30f45269b6e995ede02b910bad2418d`。
- 审阅包：`G31_20261017_阶段代码与重算证据.zip`；审阅请求：`G31_给GPTPro的阶段审阅请求_20261017.md`。
- ZIP 的 1,563 个清单项均独立检查长度与 SHA-256，未发现差异。另通过 GitHub 重新读取 6 份关键源码，全部与包内对应文件逐字节一致；其中旧 `learning.py` 位于归档 source 中。
- 主要证据前缀：`outputs/experiments/g31_ics_foundation_learning_20261017/`。当前 L0 正式记录为 `l0_002`；保留 `l0_001` 等历史负结果，不用旧稿替换新结论。

### 1.2 本次实际执行了什么

| 本次独立操作 | 结果 | 支持的结论 |
|---|---|---|
| 逐事件重放 `native_001/raw.json.gz` 的物理 receipts | 通过 | 本分支托盘身份、装卸、FIFO、边时序与容量闭合 |
| 额外重放实际 `EXPORT_GRANTED` 接收位至 `EMPTY_RECEIVED` | 3 次 grant 均闭合、未超容 | 补查本分支 parked / incoming / reception lease 的同托盘 OR 计数 |
| 检查 ACK 的接收方和送达时序 | 36 次全部符合 | 这 36 条记录的处理不早于送达，且处理 owner 与请求 owner 匹配 |
| 用保存参数独立进行 NumPy 推理 | 384 个模型分数；36 条回放记录完全一致 | 保存模型确实产生所报告的 K4/K8 保留与 regret 结果 |
| 从各 fold 的 128 条训练行重新拟合 ridge | 3 次；最大系数差约 `1.85e-14` | 线性模型与声明的训练划分、拟合公式一致 |
| 对按需预测做类型、浮点位表示和完整 JSON 哈希比较 | K4 为 4/4；两路 K8 各 8/8 一致 | 请求子集与同上下文 full32 教师计算一致 |
| 对 parity 比较器做一个真实记录副本负例 | 复现类型漏检 | `int 1` 改为 `bool True` 后，旧比较器仍报 exact |
| 检查后续当前目标的纯函数 guard | 原上下文通过；过期身份、已有接收承诺、外区动态占用注入拒绝 | 明确范围的输入/身份检查存在 |

**未在本环境重新运行 Windows native，也未独立重跑完整 pytest。**原包保存的最新 XML 是 560 项、0 failure / error / skip；这是作者运行的证据。当前环境缺 pytest、PyTorch 和原 Windows 原生组件，直接导入还受部分顶层源码缺失影响。不能把保存的 560 项报告或纯函数隔离检查写成此次重新运行了原生系统。

这里的模型推理使用提交版本的合法特征提取器；推理公式、ridge 重拟合、候选选择与指标汇总独立实现。没有重新训练 MLP，没有运行新 rollout，也没有用重算耗时替代 R1 路由更新时间。

### 1.3 包的可复现性应继续收窄表述

`fresh_native_execution_portable=False` 是正确的，但还需说明：顶层导出的 `foundation_ranker` 缺 `ics_circulation_v3.learning`，多个 foundation 模块缺 `scripts.eval`。这些依赖的一部分实际在 `budgeted_learned_001/source` 的固定归档里。该归档 125/125 份源码与 plan 哈希一致；顶层存在的 94/94 份也一致，另有 31 份只在归档中。

因此可称“证据和必要来源可审阅”，不能称“解压后的顶层目录直接可运行”。后续为审阅入口补一个明确的只读依赖映射或打包闭包即可，不必因此重做运行核心。原 Windows 路径、原始 raw 和验收身份不得静默改写；新环境实际运行必须产生新的证据身份。

## 2. 已经做好的部分：应保留，不推倒重来

### 2.1 有限托盘在同一原生机制里真实循环

本次实际机制域为 **11 节点、14 条有向边、3 个托盘、5 项业务、40 s、无故障**，初始没有预置 transfer。它继承 G31 C++ 核心；这与已在原 151 节点 / 227 边、28,506 行李 / 43,603 segments 上完成有限托盘验收是两件事。

同一托盘 L 的实际记录如下，单位均为仿真秒，按显示精度四舍五入：

| L 承载的业务 | LOAD_START | LOAD_COMPLETE | UNLOAD_COMPLETE | HOLD_COMPLETE |
|---|---:|---:|---:|---:|
| loaded | 0.000 | 0.100 | 7.200 | 7.300 |
| reuse1 | 9.550 | 9.650 | 13.050 | 13.150 |
| reuse2 | 15.360 | 15.460 | 18.460 | 18.560 |

两次返空实际接收为 **9.550、15.360 s**，下次装载不早于接收。3 个托盘身份保持，5 项业务完成，18 次进入边与 18 次退出边闭合。本次没有发现通过重建托盘、跳过卸载或凭空增加可用库存完成复用的证据。

原 receipt audit 只覆盖 parked + incoming；本次补查的接收承诺从真实 `EXPORT_GRANTED` 起计入，E 一次、L 两次全部闭合。这个结论只覆盖所读无取消分支，不外推到所有 pending / cancellation / fault 组合。

### 2.2 观察和执行权限有实际实现

原生 binding 把节点静态合同与动态库存分开：只给本 owner 节点的动态占用、可用空盘和当前相关业务；远端信息通过送达消息可见。本方 outbox 的 pending 不被执行真值自动改写，只有送达 ACK 更新可见结果。[C09]

实际 transfer grant 仍检查 source / destination 模块权限、源最小库存和目的地容量；接收权具体由原生模块的 `allow_receive` 与容量约束裁决。路由更新还检查业务、generation、traversal、已提交前缀和当前边约束。[C10]

这不是学习型 receiver 的完整 offer / accept 策略，也不是任意 Python 回调都无法绕过的安全沙箱。现阶段的合理声明是：**有明确的合法 API 边界和原生执行检查，研究代码必须遵守它。**

### 2.3 真正的按需推演已经实现

`foundation_budgeted_provider._requested()` 先选择 K；没有请求成员的 prefix 在建 context 之前跳过；已选 prefix 中的私有 runner 只对请求的 later choices fork / resume。[C05]

因此未请求的 24 项没有独立 suffix 推演或完整 prediction。部分请求项与未请求项共用的前段仍会被计算，这是共享前缀本身的必要成本。

这个改进值得保留。不过当前缓存作用域是**一次初始请求**，`initial_context_cache=False`；它还不是跨真实事件的预测复用，更不是从当前后续状态生成的局部修复。

### 2.4 L0 学习是实际完成的，不是占位接口

`l0_002` 有 192 条候选行、6 个 owner 初始决策组、3 个场景组和 43 个合法语义特征。划分按整个场景留一组，测试组没有参与拟合；标识符和候选编号没有作为输入特征。三个场景与两个 owner 的相关记录不能当作 192 个独立场景。[C07]

| K8 保存表回放 | 保留条件域最优的决策数 | 平均条件 regret | 原始 Top-1 未通过条件逐件保护 |
|---|---:|---:|---:|
| 规则 | 2 / 6 | 0.212667 s | 4 / 6 |
| 线性 | 4 / 6 | 0.106333 s | 4 / 6 |
| MLP | 5 / 6 | 0.018167 s | 4 / 6 |

这些数值独立重算通过。它们证明管道可学习到这张条件成本表的部分结构；不证明真实执行改善、机场泛化，或原始 Top-1 可以绕过保护门。

## 3. 三个主要风险

### 风险一：真实后续信息还没有形成 learner 可选择的新动作闭环

这是 L1 最直接的接口缺口，不是要求把所有研究难点先解决。

**观察不完整。**`FoundationNativeEnvironment.observe()` 仍调用 v1 `protocol_planning_snapshots(owner)`。raw 中 v1 是 .05 发布、.21 过期的初始消息；过期后保留 tombstone。实际后续采集已经使用 v3，在 7.30 / 7.32、9.55 / 9.60、9.65 / 9.67 发生。旧 retained 策略能拿到后续 v3 current context，actor 的公开字段却没有把它交出来。[C01]

**没有新动作选择。**后续 candidate 只有 `activate_retained_policy`，`submit()` 继续调用旧策略；`OwnerPolicy.decide_pending()` 在真实 `collect_native()` 之后仍调用 `fixed_choice(information, self.method)`。[C01][C02] 1717 次 activation 和 897 个 boundary 不能变成 1717 次学习决策。现有 `rl_ready=False`、`blocked_L1_not_certified` 是诚实的状态。

**模型 seed 还停留在初始条件。**已有 `later_context()` 可以组装合法后续信息，但 projection 入口仍只支持初始 bundle。初始构造重置队列、sequence、pending 和部分 availability，是其初始 fixture 假设；删除 initial guard 或改一个 `now` 并不能恢复当前真实状态。[C03][C04]

尤其 B 的后续 context 中 E 已在 3→4，P 已在 9→3。必须保留合法观察到的进入边时间和推导退出时间。生命周期构造器验证了 entry receipts，但当前返回 bundle 没有完整携带它们，seeder 需要从合法 evidence 补齐传递，不能读取 native 隐藏事件堆。

### 风险二：学习目标、公开兼容域和计算预算错位

现代码先在 32 项排序，再在昂贵推演之后调用兼容过滤。[C05][C06] 当前公开合同固定 A 的 `initial_action` 与 `return_delay`：

- A 的可选兼容候选仅 04。
- B 的公开兼容域是 `[0, 1, 4, 5, 8, 9, 12, 13]`，总共 **8 项、4 个共享前缀**。

本次在机制域保存数据上独立诊断：规则 K8 的 8 项中 **5 项不兼容**；线性 K8 的 8 项中 **7 项不兼容**，只有 04 留在该合同中。学习器预测得更好也可能只把预算花到不能作为当前兼容建议的方案上。

把公开兼容 mask 前置后，K8 正好遍历整个 B 兼容域，保存表会选 12，兼容域 regret 为 0。**这是事后保存表诊断，没有新增 live 推演耗时，也没有证明真实控制收益。**它说明下一轮缺少一个非常便宜、必要的强基线，不能把 mask 前置本身算创新。

当前真实 K8 对照的结果如下：

| 同一初始 B context | 规则 K8 | 线性 K8 | full32 教师 |
|---|---:|---:|---:|
| 实际 prefix 数 | 5 | 7 | 16 |
| prefix resume | 6 | 9 | 23 |
| suffix fork / resume | 8 / 8 | 8 / 8 | 32 / 32 |
| source proof 使用 | 17 | 17 | 65 |
| through-seal 墙钟 | 4003.4167 ms | 4888.0145 ms | 10280.5483 ms |
| 含导出和最后当前检查 | 4030.1519 ms | 4912.6517 ms | 未测同边界 |
| 最终兼容建议 | 04 | 04 | 12 |
| 条件联合 regret | 0.319 s | 0.319 s | 0 |
| 兼容域 regret | 0.119 s | 0.119 s | 0 |

full32 条件联合域最优是 25，兼容域最优是 12，两种参考不可混用。规则和线性 K8 的条件域最佳请求都是 17，最后都回到 04。

线性比规则 through-seal 多 884.5978 ms，伴随更多 prefix。当前是单 context、固定顺序记录，不能把全部差值当成学习器导致的因果效应；内部 guarded prefix 时间也包含嵌套检查，不能当纯模拟时间。**但本次没有学习质量增益、K 相同不等于计算成本相同，已经是确定的结论。**

### 风险三：条件模型保护、真实逐件保护和论文方法贡献尚未连起来

目前 `conditional_forecast` 与 full32 一致，是模型计算一致性；组件兼容是冻结 A 分量下的保守组合条件；都不自动成为从真实当前状态出发、可兑现的全程业务保证。

当前业务保护必须继续用逐件判据。若原逐件参考为 `(10, 12)`，事件后重新计算的当前 incumbent 为 `(11, 15)`，新方案为 `(11, 14)`，它虽不劣于新 incumbent，仍违反原参考。**这是一条设计反例，不是本轮发现的原生故障。**当前状态参考可用于增量估计，不能覆盖原已确立的保护参考；历史仅是预测时，也不能将其升级为实际承诺。

已提交或可能已提交的动作必须保持身份。lost ACK 不能通过新 ID 重发变成新任务；已授予接收承诺也不能仅因预测过期就释放。若实际事件使旧义务失效或无法验证，应报告 unknown / 失效及原因，不能通过更新基准擦掉退化。

当前 11 节点机制域足以开始有效 learning，但不能支撑原机场规模、真实 EBS 映射、故障全覆盖或 100 ms 结论。方法论文还需要说明边界信息为何足够、跨复用影响为什么能局部化，以及在公平基线下何时节省计算而不损害业务。

### 一个应顺手修掉的窄验证漏洞

`foundation_budgeted_probe.compare_variant()` 使用 Python `==` 判断完整 prediction 是否 exact，虽然记录两方 SHA，却未将 SHA 相等纳入通过条件。[C08]

在候选 04 的记录副本中，仅把 `prediction.projected_commands[0].id` 从整数 `1` 改成布尔 `True`，旧比较器仍返回 parity true，而两方 SHA 不同。本次真实未改动数据经更严格比较全部一致，因此不推翻历史结果。

修复范围只需让已有规范编码 / SHA 或严格类型签名参与通过条件，并加一条 bool / int 负例回归。不要为此再造一层庞大的审计框架。

## 4. 与近期近邻反复对照后的创新判断

**当前有值得继续推进的差异化研究问题；还不能保证“整体已经创新”。**实现更多模块不等于论文新增量，多个已有方法的组合也需要明确的新问题、方法或可证性质。下面按实际核读原文和本次代码比较，不把论文没研究的细节一概称为我们的已完成贡献。

| 近邻 | 已有内容与本项目的重合 | 本项目还必须做出的实质增量 |
|---|---|---|
| T2BR，TITS 2025 [L02] | 区域重定位、路线层搜索、层间反馈和学习 | 托盘卸载释放对后续可用性的内生影响，以及受区域权限约束的真实 R1/R2 执行闭环 |
| Mainhardt / Schmuck，TAC 2026 [L03] | 私有局部事件、FIFO/容量、无中心协调器的契约综合 | 异步送达与已发动作条件下可兑现的业务边界；不能把非阻塞改称逐件不劣 |
| Anand / Nayak / Schmuck，NAHS 2026 [L04] | 模板增量组合、无需每次重新协商、学习策略受许可模板约束 | 当前合法物理信息怎样支撑数值服务约束；本项目尚未实现该文模板综合 |
| GRAND，RA-L 2026 [L05] | 有限队伍的路径引导、再平衡与任务分配 | 局部送达信息和托盘服务链上的逐件约束；仅提出“路由加返空”不够 |
| FICO v3，2026 [L06] | 闭环分组、固定外部轨迹、兼容重规划、必要时扩大组 | 服务/库存依赖下的边界条件与后续真实事件；当前固定四坐标共享前缀不等于动态闭环分解 |
| 前序 LNS，2026 [L07] | 传递后继闭包、边界修补、后续时序调整 | 在线可知信息、不可撤执行与托盘多次复用的条件；换一个“影响闭包”名称不构成新方法 |
| CDCBS，CDC 2026 In Press [L08] | 回退完整证书、总成本预算过滤、分组继承及触发重分组 | 原逐件参考、局部权限与服务目标变化之间的新增方法；其固定实例和完美执行假设不能直接移用 |
| OHT Neural Double Q-routing，2026 [L09] | 保留底层安全控制，轨迹预训练后在线学习下一跳 | 同时处理 R2 与 R1 的反馈和托盘再供给；当前“离线到在线小网络”本身不是新意 |
| CASE 行李示范学习，2025 [L01] | 从专家示范学习行李路线 | 真实有限载具再利用、合法局部观察和载空流共同执行 |

本轮还保留 2015 年行李系统 loaded / empty / EBS 一体 MPC [L10] 作为“有限载具及载空耦合并非首次”的基础近邻。近期方法判断主要依据上表的新文献，不用旧论文中的周期为本项目指定刷新周期。

### 4.1 新加入的 CDCBS 必须进入论文差异表

核读版本为 `arXiv:2604.00428v1`（2026-04-01）；作者实验室现列 IEEE CDC 2026，In Press，尚未在本轮核到正式 proceedings DOI/页码。[L08] 它使“保留回退、只接受改进、继承分组、触发重算”不能单独作为本项目原创表述。

我们的逐件参考和托盘服务语义与其 fleet 总成本不同，但**仅把标量换成向量仍不自动形成方法贡献**。关键是给出合法边界信息怎样足以支撑修改和复用的条件，并在实际后续动作中验证。

### 4.2 建议保留的贡献候选

> 在有限托盘跨多次业务复用的系统中，只使用区域合法观察与已送达的边界信息，保留已发动作和原逐件保护参考，识别需要重新评估的服务与资源依赖；对仍满足条件的部分复用结果，以有限计算预算支持 R1/R2 的后续决策。

这个表述是**待验证贡献候选**，不是本次已经成立的定理。最有研究价值的内容是：

- 边界摘要至少需要哪些信息，什么时候不足、必须 unknown？
- 一次 R1 变更怎样影响卸载、空盘释放、返空和下一次乃至再下一次装载？R2 怎样通过库存与共享线路反馈 R1？
- 候选可能新占用的资源、FIFO 前驱和未来接收承诺是否进入影响范围？只沿旧路线找邻居会漏掉新冲突。
- 原逐件参考不变时，能否用比全系统重算更小的范围验证候选？如果经常扩到全域，就应报告本域没有局部性收益。
- 在相同信息、动作、保护门和总计算边界下，是否优于完整后缀 warm-start、普通后继闭包修复、兼容域穷举与简单成本规则？

论文可主张系统建模或工程实证贡献，但不能把尚未实现的局部修复、双向闭环、实时性或形式保证一并列为成果。TRE/CIE 的目标保留；投稿可行性需由下一轮方法与实验结果支撑。

## 5. 对“预测不必每次都做”的科学结论

**架构方向正确：底层物理推进、当前动作决策、预测刷新和模型训练不需要使用同一个周期。**但本次代码仅证明同一初始请求内的按需候选推演，尚未实现跨真实事件的预测缓存复用。

| 层次 | 何时工作 | 需要检查什么 |
|---|---|---|
| 原生执行、FIFO、headway、库存与接收裁决 | 原生事件到来时 | 当前物理约束，不依赖预测器可用 |
| R1 当前路由更新 | 任务/路口或相关状态要求更新时 | 当前合法输入、动作是否仍可改、已发前缀及必要保护；完整必要计算保留 ≤100 ms 目标 |
| R2 释放预测与提前返空建议 | 相关服务、需求、释放、可达性或已送达信息变化时；必要的最长寿命检查 | 预测依据是否仍有效、是否需要重算受影响部分，不能把预测量记成实际空盘 |
| 参数训练 | 离线批次或明确的模型版本更新时 | 时间/场景划分、行为日志、验证集隔离、冻结部署版本 |

可先实现简单可解释规则：出现相关新事件、预测前提失效、剩余有效时域不足或达到配置的最大信息年龄时刷新。**触发判定可以便宜且频繁，昂贵预测不必跟着每次进行。**前提未验证时不能复用；当前配置周期、阈值与 horizon 应通过本系统消融确定，不从某篇论文的秒数直接照搬。

每份预测至少记录：创建时刻、来源/消息版本、模型版本、覆盖的业务与资源、有效性条件、有效时域和失效原因。预测 TTL 不代表已发物理命令或接收承诺的 TTL。

对任务 3，比较“每个有效决策点刷新”“固定间隔刷新”“事件触发刷新”；分别记录完整预测调用数、复用率、拒绝/过期率、端到端计算和逐件业务结果。三种模式均须在新的真实 later 决策域实现和验证；现有 initial full32 仅是实现起点，不代表已完成逐决策点的滚动刷新基线。

## 6. 就绪判断：通过、未通过与未知

| 验收问题 | 本次判断 | 对下一阶段的实际影响 |
|---|---|---|
| 机制域原生有限托盘循环是否成立 | 通过，限 native_001 保存分支及明确检查范围 | 保留当前物理核心 |
| L0 数据、训练参数与保存回放是否可复核 | 通过 | 继续学习管道，不重复造基础导出器 |
| K8 是否真按需 | 通过，initial-only | 复用 provider，先修预算与兼容域 |
| 学习 K8 是否已优于规则 | 本次未通过；最终质量相同、记录耗时更高 | 保留负结果，先补公平强基线 |
| 后续 v3 信息是否已完整暴露给 actor | 未完成 | 任务 1 必做 |
| 是否存在真实后续新动作选择与执行闭环 | 未完成 | 任务 1 通过小域后立即开始任务 3 |
| 四次 shadow 是否证明所有 learner 回调隔离 | 不能；四次无命令分支均发生在 .11 s | 新的后续回调需要有针对性的隔离验证 |
| 逐件不劣是否对新学习策略成立 | 未知，尚无对应原生配对证据 | 接管结论继续受保护门和配对实测约束 |
| 100 ms 是否达标 | 未达标 | 独立保留性能工作，不阻止 offline_sync 的首次有效 learning |
| 原机场规模托盘系统是否已验收 | 未完成 | 后续扩到原地图与原负载规则；机制域结果不能代替 |
| 论文整体创新是否已经保证 | 不能保证；贡献候选明确、证据尚未闭合 | 按第 4、7 节推进新增方法与强基线 |

## 7. 下一轮最多三项编码任务

以下是工程顺序与可验收内容，不是新增七层 gate。每项交付最小可运行代码、一个明确实验结果及必要回归；不要再用一整轮文档补充替代真正动作或训练。

### 任务 1：补真实 later 观察—候选—原生执行的连接

**入口。**`FoundationNativeEnvironment.observe/candidates/submit`；`OwnerPolicy.decide_pending()` 的实际 `adapter.collect_native()` 之后、`fixed_choice()` 之前；复用 `NativeCollectionAttempt` 的当前有效性检查，及现有 `return_tray/route_tray` 提交入口。[C01][C02]

**必须完成。**

1. 新增明确版本的 actor 后续观察，暴露真实已送达 v3 信息及 `status/valid_until/capture identity`。保留 v1 字段语义；不能用列表非空代替新鲜度。
2. 执行层持有真实 current collection handle；learner 只接收 detached 合法数据，并返回候选 action ID。不能让保存的 dict 或自填的 `native_delivery_verified=True` 获得权限。
3. 先支持 B `first_reuse_route` 的 `native_default / prefer_8`。`native_default` 表示不新增偏好命令，不等同于固定 edge 3，也不负责清除已经安装的偏好。
4. 为该实际时刻实现有版本的 current-state 模型 seed，带入已完成前缀、在途边及合法 entry 时间、装卸/Storage 已知边界、FIFO、已送达 ACK 和当前动作承诺。未知必要状态必须拒绝，不能初始化成空队列、静止托盘或零 availability。
5. 同一接口随后覆盖 A `first_return`：立即返空 / 合同规定的 absolute-not-before 时间。当前 `.5` 标签对应**绝对不早于 7.84**的合同语义，不能照搬旧模型的 `now + .5`。
6. 输出 proposal、guarded action、command ID、ACK、实际执行和下一决策观察。补齐本任务必要的只读依赖入口，使离线观察/模型模块能在声明环境导入；不改历史 raw 或 Windows 验收路径。

**禁止改变。**不删 initial guard 来冒充 later 支持；不将 `FutureLaterFork` 改名充当真实当前状态；不读取 native 隐藏事件堆；不改已发动作身份、接收裁决、原逐件参考或原物理规则。A/B 独立保护结果不能直接拼成联合保护。

**最小实验。**先在已声明机制域的真实 B 采集点（保存分支约 9.69 s）比较两个候选，通过原 route 链观察实际命令的 ACK、L 的下一条 `EDGE_ENTER` 及后续业务；再在 A 返空切点做对应配对。只有实际提交命令的候选要求对应 ACK；`native_default` 记录 no-command 和空 command ID，通过真实下一跳与后续状态评估，不人为制造请求或 ACK。对照分支的前缀和输入完全相同。保留物理可执行但业务退化的评估结果；它们不能被当作策略接管通过。至少一个新的后续选择必须产生可归因的实际轨迹/状态差异，并继续到下一次决策和托盘复用。

拒绝样例只选关键的几项：过期 generation、目标托盘已有不兼容的在途/接收承诺、未送达或过期 v3、源 owner 不符、必要 entry evidence 缺失。其他已发动作应保留并建模，不是一律禁止后续决策；首个 seeder 暂不支持的合法 pending 状态明确返回 unknown。当前代码已有检查的直接复用，不重复造相同单元测试。

**全量计账。**分别记录采集开始/送达/选择/提交/ACK/物理生效时刻，guard 与推演耗时，unknown/reject/fallback 原因、真实动作身份、逐件完成差和下一次状态。标明 `offline_sync`，不把仿真时钟冻结期间的计算包装成实时新鲜度。

**完成与停止。**两个动作只有标签变化、guard 拒绝后偷偷走相同 retained 动作，均不算控制闭环完成。必要合法状态不足时返回具体缺失字段；只补支撑该小域的观测，不扩写整个世界模型。若非默认候选全都被逐件门拒绝，只能验收为有真实评估能力，可继续采样与 value/监督学习；要宣称新动作控制闭环就绪，必须有通过保护并产生实际后续差异的动作实例。B 小域通过后可立即开始该切点的监督/上下文决策学习；若整个 episode 仅有这一处有效选择，仍不能称多步 RL。多步 RL 需至少两个有效时序决策点，例如合法的 A first_return → B first_reuse_route 顺序；无选择的 activation 不计入。完整 R1/R2 贡献须等待相应真实联合序列证据。

### 任务 2：兼容域优先、按实际共享前缀计预算

**入口。**`foundation_budgeted_provider._requested/evaluate_budgeted`、`live_obligation_component_compatibility`、`foundation_ranker` 的部署评估，以及 `foundation_budgeted_probe.compare_variant`。[C05]—[C08]

**必须完成。**

1. 在昂贵推演前用当前公开合同建立 mask。A 仅保留 04；B 首先验证完整兼容域 `[0,1,4,5,8,9,12,13]`。该 mask 只能来自合法公共规则和当前已知约束，不能偷用教师保护标签筛选。
2. 直接使用现有 `candidate_indices` 入口运行 B 的兼容 8 项穷举，不另造 provider。full32 仅作为同信息教师对照，不给 actor 看完整未来结果。
3. 在更紧的 K4 或实际 prefix 预算下比较规则、冻结线性/MLP 与一个简单共享 prefix 成本规则。当前 K8 已覆盖整个兼容域，不适合继续用排序保留率证明 learning 必要性。
4. 把 candidate budget 与 prefix / wall-time budget 分别记录。建议先用可解释的增量开销估计，已有 prefix 的下一 suffix 不重复支付整段前缀成本；不急于新增大网络。
5. 修复 parity 的 bool/int 漏检，让已有 canonical prediction encoding / SHA 或严格类型签名参与通过条件，增加一个有意义的负例回归。

**禁止改变。**不为扩大搜索空间取消 A 的现有保守合同；需要新的双向合同由任务 1 的实际后续动作另行版本化验证。不删 source binding、freshness 或保护检查来取得“提速”；不在已看过机制域结果后改用 MLP 宣称预注册方案获胜。不重写本次线性 K8 负结果。

**最小实验。**首先用一个真实同 B context 验证兼容 8 项与 full32 对应 prediction 严格一致，实际只覆盖 4 个 prefix，并记录最终兼容建议。然后在该域进行 K4 的规则/成本规则/冻结模型对照。质量比较可先一轮；需要报告速度优越时，对要比较的两种方法使用预先固定的 ABBA/交错顺序及相同计时边界，保留冷启动与热运行分别计账。没有必要为这个小修复重新穷举整个故障矩阵。

**全量计账。**至少记录合法域大小、评分行数、实际候选数、不同 prefix 数、context 构造、prefix resume、suffix fork/resume、proof 使用、source setup、guard、导出和最后当前检查。总成本采用实际调用计数和互斥耗时分解，不能把有嵌套关系的计时直接相加。

可用于设计的成本式为：

\[
T(S)=T_{\mathrm{fixed}}+\sum_{g\in\mathrm{prefix}(S)}T_g
+\sum_{a\in S}T_{a\mid g(a)}+T_{\mathrm{required\ checks}}.
\]

这个式子描述需度量的工程成本，不声称已经构造了准确预测模型或新理论。

**完成与停止。**现有数据的合理预期是兼容 8 项覆盖 12，兼容域条件 regret 为 0；必须以新 live 结果确认，不能预填通过。若紧预算下学习不胜成本规则，保留规则并推进真实多步数据，不再在原三场景重复调网络。总调用范围和完整计时不一致时不作加速结论。

### 任务 3：开始真正的多步 learning，并验证一次服务依赖驱动的更新

**入口。**在任务 1 的新 transition 之上扩展 `foundation_learning_data`、ranker / learner 与 `run_learning_pipeline.train-rl`。新 later schema 与旧 `owner_public_features.v2` 分开；旧特征只接受初始字段及最多一个 planning capture，不能不改语义就用于多次 v3 观察。

**内部顺序。**首次 value/监督更新可在一个有效切点就绪后开始；首次多步 RL 在至少两个有效时序决策点就绪后开始，并交付冻结 checkpoint 与独立 episode 评估。服务后缀修复对照、四类场景扩展和原机场地图实验是本任务随后交付，不阻塞第一次训练。

**必须完成。**

1. 先采集有至少两个有效时序决策点的原生 episode，跨装卸、返空和同托盘再装载。每条 transition 保存合法 `observation`、候选 mask、proposal、guard 后动作、实际动作/拒绝、下一观察、`delta_sim_time`、终止/截断标志及模型版本。初始 32 个 counterfactual 不能展开成 32 条真实轨迹。
2. 首轮使用小模型和现有可维护训练实现，完成一次真实参数更新、冻结 checkpoint、独立 episode 评估。可以先用监督 continuation/value 预训练再做离散动作的多步 RL；预训练不能替代最终的真实多步训练结果。不要仅修改 `rl_readiness()` 的返回值。
3. 时间间隔不等的事件需正确进入回报计算。若使用折扣，明确时间单位及 `delta_sim_time` 的处理；或者使用明确的有限 episode 不折扣目标。严格逐件保护仍由独立判据决定，不能用总回报平均化。
4. 同时实现一种最简单的事件刷新规则，记录服务/释放预测的来源、失效条件和复用范围。围绕一次实际送达的服务或释放变化，比较完整后缀重算与依赖范围内重算；冻结已发前缀，保留原逐件参考。对未覆盖状态返回 unknown。
5. 训练数据按完整 episode / 场景 / 时间窗分组；生成或选择新上下文前固定训练、验证、测试划分。重复 seed 的相同确定性场景不增加独立样本数。记录行为策略；没有支持度的离线动作不做无依据的 off-policy 效果宣称。
6. 小域贯通后接回原 151 节点 / 227 边的地图与既定负载生成规则，用 4070 电脑和 5080 服务器开展分工；必要时提高同图负载产生自然冲突，不改容量、添无限托盘、删除难任务或换拓扑制造收益。

**禁止改变。**不以未知未来到达、全局即时 peer 库存或 raw 真值补 actor 观察；训练/评估标签可用明确标识的离线真值，执行 actor 和 guard 的信息范围必须分别记录。不能把局部模型预测改标成 hard reservation，不能把理论性质从近邻论文直接继承。

**最小实验。**首次多步训练只需一个已通过的小域及至少两个有效时序决策点，不等全部场景完善。随后逐项覆盖正常重复复用、确实发生的缺盘等待、载空共享资源冲突，以及一次实际送达的新信息改变后续可选动作；这四类是本任务后续评估目标，不阻止第一次参数更新和独立 episode 评估。其他复杂故障单独标 unknown。对照使用相同信息、动作、输入 tape、seed、逐件门与计算范围的 incumbent、成本规则和新策略。新策略至少有一条可追踪的参数更新→新动作→实际后续状态的链路。

方法验证只做一类服务后缀更新：与完整后缀 warm-start 和普通前序后继闭包修复比较。把“无逐件保护”仅作为隔离离线诊断，不作为合格部署基线。若要借鉴 FICO/CDCBS 的结构，明确适配了哪些假设；不宣称原算法在本项目的异步库存系统中已原样复现。

**全量计账。**每件业务的相对完成时间、等待空盘时间、实际载/空边占用、完成数、未完成/死锁、拒绝与 fallback、预测调用/复用、训练/推理/推演/必要检查耗时、峰值内存和明确硬件环境均入结果。总体均值、p95/p99 与逐件违反数分开；100 ms 继续按一次必要请求完整计算边界单列，不用 GPU 推理时间替代。

**完成与停止。**成功意味着真正训练并评估了多步策略，而不是增加训练命令。若影响闭包经常扩到全域，就承认本域没有局部计算优势；若新策略没有超越简单基线，保留负结果，检查状态、动作和自然场景差异，而非通过放松保护换提升。若新事件使原义务失效，记录失效原因，禁止覆盖基准。第一轮不要求论文全部性质已证明，但未证明部分不得写成 guaranteed claim。

## 8. 必须保留的研究约束

- 最终形态是考虑有限托盘循环的区域去中心化 ICS；训练可集中组织，执行的 actor 与 guard 需分别明确合法信息来源。
- R1：区域内载盘路线按需更新，完整必要单任务路由更新计算保留 ≤100 ms 目标；运行时沿用 G31 的既有策略与 PIBT-lite fallback，不引入运行时 A* 替换核心。
- R2：依据当前已知业务目的地、路线和服务信息预测未来空盘释放，提前形成跨区空盘调度建议；现有区内模块权限保留，实际释放/源库存/接收位才能支撑真实动作。
- 同一托盘 ID 贯穿装载、卸载、Storage/EBS、空载、在途与再利用；载空流共用原 FIFO/headway/capacity 约束。
- 严格逐件不劣保留零容忍语义；保护的是原明确定义的业务参考，不是每次重算后变差的新参考。完整参考失效与“候选不劣”分开报告。
- 原地图、原业务规模与负载生成规则保留。当前零容量边 dense97→98 / ICS103→104 的 storage 与通行语义、实际 EBS 映射仍需独立解决；不将它们当作已完成，也不要求这些全域问题先阻止受限小域 learning。
- 不擅自添加无限托盘、借全局即时库存、绕过 receiver 权限、改变已发动作身份或用离线 A* 专家掩盖运行时算法变更。
- 本次 ranker 在 CPU 上训练；4070 / 5080 是后续资源安排，不是本次已经使用 GPU 训练的证据。设备型号和环境均应随每次实验实报。

## 9. 应撤回或收窄的现有表述

| 不宜继续使用的宽表述 | 本轮允许的准确表述 |
|---|---|
| 已完成 G31 机场规模有限托盘系统 | 已完成继承 G31 原生核心的 11 节点机制域循环证据 |
| 已支持多步 RL 环境 | 后续 retained 激活已实现，真实新动作学习接口待补 |
| four shadow 证明任意 learner 推理不影响物理系统 | 四次 .11 s 无命令 shadow 分支保持 native hash；新的后续回调另测 |
| 学习 K8 已显著提速且保留更优执行结果 | 此次线性 K8 建更多 prefix、耗时更长，最终兼容建议相同 |
| full32 parity 证明真实物理预测绝对准确 | 请求子集与相同信息和模型的 full32 计算一致 |
| Top-K 命中联合最优就能改善去中心化执行 | 还需公开兼容域、当前提交检查及真实逐件结果 |
| 已经实现动态局部修复 / 跨事件缓存 | 当前只是一次初始请求中的固定候选共享前缀复用 |
| 非阻塞或总成本下降等价于逐件不劣 | 三者是不同性质，需要分别定义和验证 |
| 保留证书、事件触发和学习加保护就是创新 | 已有直接近邻；新贡献需由服务依赖与合法边界方法及实验支撑 |
| 全部 560 项由本次审阅重新运行通过 | 读取作者保存的 560 项零失败报告；本次独立执行另有明确范围 |

## 10. 代码与证据索引

所有源码链接固定在 `da8d39ed`，后续修订应记录新的提交，不能让本审阅自动覆盖新代码。

- [C01：FoundationNativeEnvironment](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_native_environment.py)：`CAPABILITIES`；`observe` 133—144；`candidates` 146—156；`submit` 158—207；shadow 调用 338—341。
- [C02：后续真实采集与 retained 决策](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/live_obligation_recollection_policy.py)：`decide_pending` 277 起；299 的 `fixed_choice`；309—329 的 current target 与提交。
- [C03：后续生命周期信息](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/live_obligation_lifecycle_state_v2.py)：`later_bundle` 122—183；pending、entry、OR occupancy 和 source records 条件。
- [C04：当前 projection 的初始边界](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/public_live_obligation_communication_projection.py)：初始构造 31—43；`predict` 389—400。配合 `live_obligation_delivered_context.py` 的 later context / initial projection bundle 阅读。
- [C05：真按需 provider](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_budgeted_provider.py)：subset runner 45—108；排序 160—173；保护/兼容 176—192；执行 225—287。
- [C06：公开组件兼容合同](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/live_obligation_component_compatibility.py)：`OWNER_FIELDS`、`select_component`、`compatible`。
- [C07：ranker 与保存回放](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_ranker.py)：训练目标 20—91；推理 104—128；回放 137—183。合法特征见同目录 `foundation_learning_data.py`。
- [C08：预算对照比较器](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_budgeted_probe.py)：137—145 的 Python 相等与 SHA 记录。
- [C09：原生 owner 观察](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/cpp/ics_core/bindings/circulation_session_binding.hpp)：180—238 的 owner 数据；500—542 的 pending / ACK 可见性。
- [C10：原生 grant 与 route 生效检查](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/cpp/ics_core/runtime/circulation_runtime_impl.hpp)：444—478、495—533。OR occupancy 在 `circulation.hpp` 390—400。
- [C11：学习命令及 readiness](https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/run_learning_pipeline.py)：167—175；CLI 的 Windows 有界执行入口 235 起。

主要证据文件（相对于第 1 节实验前缀）：

| 证据 | 位置 |
|---|---|
| 原生机制记录 | `native_001/raw.json.gz`、同目录 report / receipt |
| L0 行与模型 | `l0_002/collect/decision_rows.jsonl`、`l0_002/models/`、`l0_002/heldout_replay.json` |
| K4 真按需 | `budgeted_001/` |
| 冻结学习 K8 真对照 | `budgeted_learned_001/` 的 raw、callback、report、plan、source |
| CLI 首轮 | `pilot_001/` |
| 作者最终测试 | `final_validation_001/tests.xml`、`receipt.json`、`plan.json` |
| 原有只读复核报告 | `offline_review_verification_001.json`，其 scope 明确没有做模型推理 |

## 11. 文献账：版本、定位和可支持范围

本轮重点复读用户先前上传的 TAC、NAHS、T2BR 原文，并重新打开 FICO、LNS、GRAND、OHT 与新增 CDCBS。以下 DOI 和公开原文用于定位；无法核实的正式出版信息不补猜。PDF 页码按所读公开/上传版本计算，不把 PDF 文件页码误作期刊页码。旧任务书完整 34 篇账仍保留；下面列直接影响本次决定的 10 篇。L01—L10 是本文件的局部编号，旧任务书的编号以旧文件为准。

### L01 — 行李示范学习，2025

Tian, Keyu; Zeng, Li. **Learning Optimal Baggage Routing from Expert Demonstrations.** IEEE CASE 2025, 1604–1610. [DOI](https://doi.org/10.1109/CASE58245.2025.11163851)。已读用户上传全文；用于路由学习近邻，不能为有限托盘再利用与本项目局部权限提供保证。

### L02 — T2BR，TITS 2025

Chen, Taijie; Liu, Jingyun; Feng, Siyuan; Qiu, Jiandong; Ke, Jintao. **T2BR: A Hierarchical Repositioning Approach for Autonomous Mobility on Demand Systems.** IEEE TITS 26(12), 23139–23150. [DOI](https://doi.org/10.1109/TITS.2025.3620346)；[作者机构记录](https://ira.lib.polyu.edu.hk/handle/10397/118606)。本轮复读 §III—IV，PDF 3—5；§VII-C，9。区域状态和平台执行假设与本项目不同。其批量调度/推理时间不能作为本项目 100 ms 验收口径。

### L03 — 去中心化监督契约，TAC 2026

Mainhardt, Ana Maria; Schmuck, Anne-Kathrin. **Synthesis of Distributed and Decentralized Supervisory Control via Contract Negotiation.** IEEE TAC 71(9), 5892–5907. [DOI](https://doi.org/10.1109/TAC.2026.3682203)。作者接收稿标题拼写为 *Decentralised*。本轮复读 PDF 1—2、7—9、11—12；尤其共享/私有事件、额外非阻塞条件和信号更新假设。不借其形式结论替代异步托盘业务保护。

### L04 — 不确定性下多智能体逻辑控制，NAHS 2026

Anand, Ashwani; Nayak, Satya Prakash; Schmuck, Anne-Kathrin. **Contract-based multi-agent logical controller synthesis under uncertainty.** Nonlinear Analysis: Hybrid Systems 62, 101783（期号标为 November 2026，已在线可读）。[DOI](https://doi.org/10.1016/j.nahs.2026.101783)；[原文页面](https://www.sciencedirect.com/science/article/pii/S1751570X26001093)。本轮复读 PDF 3—4、19—21，特别是 §7.2—7.3。其给定联合博弈图和逻辑模板并非本项目的数值库存模型。

### L05 — GRAND，RA-L 2026

Gaber, Johannes; Alharbi, Meshal; Gammelli, Daniele; Zardini, Gioele. **GRAND: Guidance, Rebalancing, and Assignment for Networked Dispatch in Multi-Agent Path Finding.** IEEE RA-L 11(5), 5470–5477. [DOI](https://doi.org/10.1109/LRA.2026.3673902)；[所读公开全文 v3](https://arxiv.org/html/2512.03194v3)。用于检查引导、再平衡与分配的组合重合；不从其全局分布与优化层移植本项目的去中心化权限保证。

### L06 — FICO，公开 v3，2026-01-06

Li, Jiarui; Zanardi, Alessandro; Pecora, Federico; Zhang, Runyu; Zardini, Gioele. **FICO: FInite-Horizon ClOsed-Loop Factorization for Unified Multi-Agent Path Finding.** [arXiv:2511.13961v3](https://arxiv.org/html/2511.13961v3)，首次发布 2025-11-17；本轮未确认正式接收。重点 §V-B—E 的冻结、兼容分解与重组。不是仅凭邻居数量判定可复用。

### L07 — 前序任务的 LNS，2026-03-30

Parimi, Viraj; Williams, Brian. **Large Neighborhood Search for Multi-Agent Task Assignment and Path Finding with Precedence Constraints.** [arXiv:2603.28968v1](https://arxiv.org/html/2603.28968v1)。本轮未确认正式接收。重点 §2.2、§3、§4.2—4.3。其离线已知任务前序与项目在线合法信息不同；后继闭包和边界重定时本身已有先例。

### L08 — CDCBS，新增强近邻，2026

Li, Jiarui; Zhang, Runyu; Zardini, Gioele. **Certificate-Driven Closed-Loop Multi-Agent Path Finding with Inheritable Factorization.** [所读 arXiv v1](https://arxiv.org/html/2604.00428v1)，2026-04-01；[作者实验室出版页](https://zardini.mit.edu/publications/)列 IEEE CDC 2026，In Press。重点 §II-A / Problem 1（PDF 2 页）与 §III—V（PDF 3—6 页）。正式 proceedings DOI/页码本轮未核实。

### L09 — 工业 OHT 的下一跳学习，2026-08-31

Gu, Cheng; Zhao, Qiusheng; Liu, Anbang; Lin, Shaochong; Shen, Max Z. J. **Trajectory-Initialized Neural Double Q-Routing for Large-Scale Overhead Hoist Transport Systems.** [arXiv:2608.30512v1](https://arxiv.org/html/2608.30512v1)。公开稿声明 submitted to IEEE，不能称已接收。核读 §III—IV 与限制：它改变分岔处下一跳，任务 dispatch 另行处理。用于比较预训练、小网络和保留底层控制的方案。

### L10 — 有限行李载具载空一体控制的基础近邻，2015

Zeinaly, Y.; De Schutter, B.; Hellendoorn, H. **An Integrated Model Predictive Scheme for Baggage-Handling Systems: Routing, Line Balancing, and Empty-Cart Management.** IEEE TCST 23(4), 1536–1545. [DOI](https://doi.org/10.1109/TCST.2014.2363135)；[作者公开 PDF](https://www.bartdeschutter.org/publications/15-019-integrated-model-predictive-scheme/15-019-integrated-model-predictive-scheme.pdf)。仅用于保留已存在的载空耦合近邻事实，不能据此为本项目设定周期或声称实时达标。

## 12. 本次独立重算方法与结论留档

数据 SHA-256：`70e1f7d5e643ad86e118a6358d60b6b616d877b1ca76ae2e4e68b45f37f33a57`（`l0_002/collect/decision_rows.jsonl`）。

重算过程：逐行重新提取合法 43 维特征，核对保存特征；按整个场景留一划分读取六个冻结 fold 模型；线性按标准化后向量与系数内积加截距，MLP 按保存的 3 层权重、两次 tanh 和目标反标准化推理；按原 tie-break 与强制保留 04 重算 K4/K8；最终与 36 条保存记录逐字段核对。每 fold 另用 128 条训练行按 ridge `alpha=1` 重拟合，均值/尺度/截距完全一致，系数差仅为数值平台浮点误差。

| 模型 | K4 条件最优保留 | K4 平均 regret | K8 条件最优保留 | K8 平均 regret |
|---|---:|---:|---:|---:|
| 规则 | 2/6 | 1.3793333333 s | 2/6 | 0.2126666667 s |
| 线性 | 4/6 | 0.8063333333 s | 4/6 | 0.1063333333 s |
| MLP | 4/6 | 0.8063333333 s | 5/6 | 0.0181666667 s |

机制域 B 的原 K8 不兼容项：规则 `[2,16,3,18,17]`，线性 `[16,20,24,28,18,17,22]`。mask 前置后的保存表 K8 覆盖完整兼容域，规则/线性/MLP 均选择 12、兼容 regret 0，均需 4 个 prefix；这是新的诊断结果，不能替换原已冻结的 live 对照。

按需 provider 独立复核还确认：K4、规则 K8、线性 K8 的实际 prefix 分别 3/5/7，suffix 分别 4/8/8，proof 分别 9/17/17；未请求候选分别 28/24/24，均无完整 prediction。完整预测真实数据的类型、浮点表示和哈希一致。原比较器的 bool/int 漏检单独保留，不能用历史通过掩盖该漏洞。

[C01]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_native_environment.py
[C02]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/live_obligation_recollection_policy.py
[C03]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/live_obligation_lifecycle_state_v2.py
[C04]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/public_live_obligation_communication_projection.py
[C05]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_budgeted_provider.py
[C06]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/live_obligation_component_compatibility.py
[C07]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_ranker.py
[C08]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/scripts/experiments/g31_ics_circulation/foundation_budgeted_probe.py
[C09]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/cpp/ics_core/bindings/circulation_session_binding.hpp
[C10]: https://github.com/czr5454112-glitch/jichang_origin/blob/da8d39ed4e36b6db31e3a7a6b17b0f73b85eed9a/cpp/ics_core/runtime/circulation_runtime_impl.hpp
[L01]: https://doi.org/10.1109/CASE58245.2025.11163851
[L02]: https://doi.org/10.1109/TITS.2025.3620346
[L03]: https://doi.org/10.1109/TAC.2026.3682203
[L04]: https://doi.org/10.1016/j.nahs.2026.101783
[L05]: https://arxiv.org/html/2512.03194v3
[L06]: https://arxiv.org/html/2511.13961v3
[L07]: https://arxiv.org/html/2603.28968v1
[L08]: https://arxiv.org/html/2604.00428v1
[L09]: https://arxiv.org/html/2608.30512v1
[L10]: https://doi.org/10.1109/TCST.2014.2363135
