# G31 独立审阅包

先读 `00_给GPTPro的审阅请求.md`。本包是未提交的源码与证据逐字节快照；基线为 da8d39ed，不声称已推送。

独立轻量复核（Python 3.11+，只用标准库；不 import 项目、不训练、不推理、不启动 native）：

```text
python verify_bundle.py .
python verify_bundle.py /path/to/bundle.zip
```

`MANIFEST.sha256.json` 逐字节覆盖除自身外全部文件；自身哈希以交付 ZIP SHA 为外部身份。
`PATH_MAP.json` 将原绝对路径与特定 SHA 映射到实际包成员。原始 JSON、换行、浮点/类型与失败记录均不改写。
`repo/` 是可审阅/导入的当前源闭包；`historical_sources/` 仅存已登记旧版本，不会暗中替换当前 import。
独立核查范围由 `AUDIT_SPEC.json` 明示；计时重算只重算已有数字，不是重跑性能实验或 100 ms 证明。
失败、未知、未执行证据不升级为成功。测试 XML 是保存的执行结果，不宣称解压后已重跑测试。
`SOURCE_CLOSURE.json` 与 `IMPORT_SMOKE.json` 说明真实依赖及隔离导入结果；外部库不随包安装。
`HISTORICAL_SOURCE_GAPS.json` 单独列明未保留的旧中间源码版本；原登记 SHA 不改写，不把这些历史缺项伪称已复核，当前最终测试/原生执行版本不能借此豁免。

**本包不是可移植 native 部署镜像。** Windows 解释器、native026/native027 二进制/构建与旧准入路径没有全部打包，见 `NATIVE_DEPENDENCIES_NOT_BUNDLED.json`。
不得通过修改旧哈希、绝对路径、保护条件来伪造 fresh-native 成功。轻量复核与原生重放是两个不同门。
文献正文不在包内转授权转载；以仓库文献映射文档中的原作者 URL、版本及章节支持范围为准。
