"""Terminal-flow paired stages sharing the existing native and resource ledger.

prepare-block freezes concrete plans; run-block executes only those plans;
evaluate retains failures and per-parent differences. No work runs on import.
"""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import secrets

from . import foundation_airport_joint_campaign as campaign
from . import foundation_airport_joint_budget as budget
from .foundation_airport_inventory_spi_campaign import bound, read_bound
from .foundation_airport_transport_allocation import DEFAULT_CONFIG

SCHEMA = "g31.terminal_flow.campaign.v1"
ROOT = campaign.CYCLE / "terminal_flow"
BLOCKS = {
    "gate": (2101,), "confirm": (2101,), "bridge": (2201, 2202, 2203, 2204),
    "bins": (2201, 2202, 2203, 2204), "period": (2201, 2202, 2203, 2204),
    "predictor": (2201, 2202, 2203, 2204),
}
METHODS = {
    "gate": ("C00", "C10", "TF-current", "TF-B1-60", "TF-B1-300"),
    "confirm": ("TF-current", "TF-B1-60", "TF-B1-300"),
    "bridge": ("C00", "C10", "TF-current", "TF-B1-60"),
    "bins": ("TF-B1-300",), "period": ("TF-B1-300-replan300",),
    "predictor": ("TF-predictor",),
}


def read(path):
    path = Path(path)
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf8") as stream:
            return json.load(stream)
    return campaign.common.read(path)


def write_once(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    return bound(path)


def prepare_block(name, *, phase, source, parents=None, demand_model=None):
    """No additional campaign budget; unused old phase quotas remain bounded."""
    if phase not in BLOCKS:
        raise ValueError("terminal_flow:unknown_phase")
    selected = tuple(parents or BLOCKS[phase])
    if not selected or len(selected) != len(set(selected)) or not set(selected) <= set(BLOCKS[phase]):
        raise ValueError("terminal_flow:registered_parent_block")
    status = budget.status(campaign.CYCLE)
    if status["open_runners"] or status["unfinished_native_tasks"]:
        raise ValueError("terminal_flow:active_or_unresolved_old_work")
    directory = ROOT / name
    if directory.exists():
        raise ValueError("terminal_flow:fresh_block_name")
    source_ref = bound(source)
    read_bound(source_ref)
    if phase in ("gate", "confirm"):
        calibration = dict(before_training=True, horizon=18000., soft_seconds=660.,
            hard_seconds=720., estimated_evidence_bytes=128*1024**2,
            basis="same_native030_eight_closed_18000s_gates_max61.94s; conservative_new_solver_allowance")
        calibration_ref = write_once(directory/"calibration.json", calibration)
        batch = "reserve"
    else:
        calibration_ref = bound(campaign.CYCLE/"runtime_calibration_001.json")
        calibration = read_bound(calibration_ref)
        batch = "development" if phase in ("bridge", "bins") else "initial"
    mapping = bound(campaign.CYCLE/"training/mapping_fit_001/mapping.json")
    model_ref = bound(demand_model) if demand_model else None
    if phase == "predictor" and model_ref is None:
        raise ValueError("terminal_flow:predictor_model_required")
    needed = len(selected)*len(METHODS[phase])
    limits = read(campaign.CYCLE/"campaign_budget.json")
    if status["by_batch"][batch]+needed > limits["allocations"][batch]:
        raise ValueError("terminal_flow:whole_block_batch_budget")
    if status["native_starts"]+needed > limits["native_start_limit"]:
        raise ValueError("terminal_flow:whole_block_native_budget")
    if status["active_seconds"]+needed*calibration["hard_seconds"] > limits["active_seconds_limit"]:
        raise ValueError("terminal_flow:whole_block_active_time_budget")
    evidence = needed*calibration["estimated_evidence_bytes"]
    if (status["evidence_bytes"]+evidence >= limits["new_evidence_bytes_limit"]
            or status["free_bytes"]-evidence < limits["free_space_floor_bytes"]):
        raise ValueError("terminal_flow:whole_block_disk_budget")
    tasks = []
    for seed in selected:
        for method in METHODS[phase]:
            task = campaign.prepare(f"TF_{name}_{method}_P{seed}", method=method, seed=seed, batch=batch,
                source_bundle=source_ref, mapping=mapping, calibration=calibration_ref,
                demand_model=model_ref, transport_config=DEFAULT_CONFIG,
                **{k: calibration[k] for k in ("horizon", "soft_seconds", "hard_seconds", "estimated_evidence_bytes")})
            tasks.append(bound(task/"plan.json"))
    result = dict(schema=SCHEMA, name=name, phase=phase, parents=list(selected), methods=list(METHODS[phase]),
        task_plans=tasks, source_bundle=source_ref, prior_budget=status, batch=batch,
        fixed_allocator=DEFAULT_CONFIG, demand_model=model_ref,
        old_action_Q_stages="not_dispatched; preserved_unchanged_historical_registration",
        formal_test_locked=True, R1_enabled=False, no_claim_of_service_improvement=True)
    write_once(directory/"block.json", result)
    budget.append(campaign.CYCLE, "terminal_flow_block_registered", block=bound(directory/"block.json"),
        rationale="new demand-only prediction and transport allocation; reuse unspent existing quotas")
    return result


def run_block(path):
    block = read(path)
    if block.get("schema") != SCHEMA:
        raise ValueError("terminal_flow:block_schema")
    status = budget.status(campaign.CYCLE)
    if status["open_runners"] or status["unfinished_native_tasks"]:
        raise ValueError("terminal_flow:recover_existing_runner_first")
    identity = "terminal-flow-"+secrets.token_hex(12)
    budget.append(campaign.CYCLE, "runner_open", runner_id=identity, purpose=block["name"])
    try:
        for reference in block["task_plans"]:
            plan = read_bound(reference)
            result = campaign.launch(Path(reference["path"]).parent)
            print(json.dumps(dict(task_id=plan["task_id"], status=result["worker"]["scientific_status"])), flush=True)
            if result["worker"]["scientific_status"] != "closed":
                break
    finally:
        budget.append(campaign.CYCLE, "runner_close", runner_id=identity)
    return evaluate([path])


def evaluate(paths):
    rows = []
    for path in paths:
        block = read(path)
        for ref in block["task_plans"]:
            plan = read_bound(ref)
            directory = Path(ref["path"]).parent
            receipt = read(directory/"receipt.json") if (directory/"receipt.json").exists() else None
            row = dict(parent=plan["parent"]["parent_seed"], method=plan["method"], task_id=plan["task_id"],
                horizon=plan["horizon"], status="not_started" if receipt is None else receipt["worker"]["scientific_status"],
                receipt=None if receipt is None else bound(directory/"receipt.json"))
            row["comparison_contract"] = dict(input=plan.get("input", {}).get("sha256"), binary=plan.get("binary", {}).get("sha256"),
                sources=plan.get("source_bundle", {}).get("sha256"), controller=plan.get("controller"),
                mapping=plan.get("mapping"), projection_horizon=plan.get("projection_horizon_seconds"),
                supply_mode=plan.get("supply_mode"), activation=plan.get("activation"),
                allocator=plan.get("transport_config"))
            if receipt is not None:
                row.update(cost=receipt["worker"].get("cost"), funnel=receipt["worker"].get("funnel"),
                    timing=receipt["worker"].get("policy_timing"), wall_seconds=receipt["worker"].get("wall_seconds"),
                    peak_memory_bytes=receipt["worker"].get("peak_memory_bytes"))
            trajectory = directory/"trajectory.json.gz"
            if row["status"] == "closed" and trajectory.exists():
                data = read(trajectory)
                acts = [r for r in data["rows"] if r["requested_action"]["kind"] != "noop"]
                row.update(system_J=data["system_J"], proposed=len(acts),
                    submitted=sum(bool(r.get("actual_submission")) for r in acts),
                    accepted=sum(any(a.get("status") in ("accepted", "granted", "dispatching", "departed", "in_transit", "received")
                                     for a in (r.get("ack") or [])) for r in acts),
                    received=sum(r.get("received_event") is not None for r in acts),
                    physical_failure=sum(bool(r.get("physical_failure")) for r in acts),
                    planned_quantity=sum(r.get("planned_quantity", 0) for r in data["rows"]),
                    plan_quantity_denominator="rolling_suggestions_including_replans; not_unique_orders",
                    cache_hits=sum(r.get("flow_cache", {}).get("hit", False) for r in data["rows"]),
                    policy_decisions=len(data["rows"]))
            rows.append(row)
    pairs, missing = [], []
    for row in rows:
        reference_method = ({"TF-B1-300": "TF-B1-60", "TF-B1-600": "TF-B1-60",
            "TF-B1-near-fine": "TF-B1-60", "TF-B1-300-replan300": "TF-B1-300",
            "TF-predictor": "TF-B1-300", "TF-B1-60": "C10", "TF-current": "C00", "C10": "C00"}
            .get(row["method"]))
        if reference_method is None:
            continue
        baseline = next((r for r in rows if r["parent"] == row["parent"] and r["method"] == reference_method
                         and r["horizon"] == row["horizon"] and r["status"] == "closed"), None)
        if baseline and row["status"] == "closed" and "system_J" in row:
            left, right = dict(row["comparison_contract"]), dict(baseline["comparison_contract"])
            if not reference_method.startswith("TF"):
                left.pop("allocator", None); right.pop("allocator", None)
            if left != right:
                missing.append(dict(task_id=row["task_id"], reference=reference_method, reason="comparison_contract_mismatch"))
                continue
            pairs.append(dict(parent=row["parent"], method=row["method"], reference=reference_method,
                backlog_gain_bag_seconds=baseline["system_J"]-row["system_J"], horizon=row["horizon"]))
        else:
            missing.append(dict(task_id=row["task_id"], reference=reference_method, reason="missing_closed_paired_baseline_or_candidate"))
    return dict(schema=SCHEMA+".evaluation", runs=rows, paired=pairs,
        missing_pair_reasons=missing,
        all_registered_closed=bool(rows) and all(r["status"] == "closed" for r in rows),
        formal_test_locked=True, strict_per_bag_nonharm_certified=False,
        conclusions="mechanism and development evidence only; no TEST or R1 combination claim")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status")
    p = sub.add_parser("prepare-block")
    p.add_argument("name"); p.add_argument("--phase", choices=tuple(BLOCKS), required=True)
    p.add_argument("--source", type=Path, required=True); p.add_argument("--parents", nargs="+", type=int)
    p.add_argument("--demand-model", type=Path)
    p = sub.add_parser("run-block"); p.add_argument("block", type=Path)
    p = sub.add_parser("evaluate"); p.add_argument("blocks", nargs="+", type=Path); p.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.command == "status":
        result = budget.status(campaign.CYCLE)
    elif args.command == "prepare-block":
        result = prepare_block(args.name, phase=args.phase, source=args.source,
                               parents=args.parents, demand_model=args.demand_model)
    elif args.command == "run-block":
        result = run_block(args.block)
    else:
        result = evaluate(args.blocks)
        if args.output:
            write_once(args.output, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
