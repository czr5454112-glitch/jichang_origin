"""Bounded prospective isolated evaluation with streamed current-state audit."""
from __future__ import annotations

import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
from pathlib import Path
import secrets
import shutil
import sys
import time
import traceback

from . import foundation_airport_action_campaign as common
from .foundation_airport_batch_patch import digest, require
from .foundation_airport_pair_dataset import window_cost
from .foundation_airport_prospective_control import make_prospective_planner, make_ranker_planner

MODULE = "scripts.experiments.g31_ics_circulation.foundation_airport_prospective_campaign"
SCHEMA = "g31.foundation.airport_prospective_campaign.v1"
IDENTITY = "airport_prospective_isolated_r2_v1"


def bound(path):
    return {"path": str(Path(path).resolve()), "sha256": common.sha(path)}


def read_bound(reference):
    require(isinstance(reference, dict) and common.sha(reference["path"]) == reference["sha256"],
        "prospective_bound_artifact_bytes")
    return common.read(reference["path"])


def validate_grid(grid, *, name, batch, seed, fleet, information_variant, training_domain, model_seed):
    require(grid["schema"] == "g31.frozen_prospective_evaluation_grid.v1"
        and grid["test_opened"] is False, "frozen_pretest_prospective_grid")
    found = [row for row in grid["rows"] if row["name"] == name]
    expected = dict(name=name, batch=batch, parent_seed=seed, fleet=fleet, variant=information_variant,
        training_domain=training_domain if information_variant in ("C01", "C11") else None,
        model_seed=model_seed if information_variant in ("C01", "C11") else None)
    require(found == [expected], "exact_registered_prospective_cell")
    require(grid["activate_at"] == grid["cost_window"][0] == 7200.
        and grid["horizon"] == grid["cost_window"][1] == 59400., "frozen_full_cost_window")


def validate_model_freeze(reference, *, split, information_variant, training_domain, model_seed):
    if split != "test" and information_variant in ("C00", "C10"):
        return None
    from .foundation_airport_pair_training_campaign import validate_frozen_manifest
    manifest = validate_frozen_manifest(reference, required_domains=["primary_22", "mixed_18_22_26"])
    if information_variant in ("C00", "C10"):
        return None
    rows = [row for row in manifest["models"] if row["training_domain"] == training_domain
        and row["information_variant"] == information_variant and row["seed"] == model_seed]
    require(len(rows) == 1, "selected_frozen_ranker_cell")
    return rows[0]


def prepare(name, binary, *, seed, fleet, information_variant, batch, rule_freeze,
            grid_freeze=None, model_freeze=None, training_domain="primary_22", model_seed=17):
    """Prepare only; launch is a separate explicitly budgeted native operation."""
    grid_freeze = grid_freeze or bound(common.CYCLE / "prospective_evaluation_grid_001.json")
    grid = read_bound(grid_freeze)
    validate_grid(grid, name=name, batch=batch, seed=seed, fleet=fleet,
        information_variant=information_variant, training_domain=training_domain, model_seed=model_seed)
    split = {701: "train", 702: "train", 801: "dev", 802: "dev", 901: "test", 902: "test"}[seed]
    selected = validate_model_freeze(model_freeze, split=split,
        information_variant=information_variant, training_domain=training_domain, model_seed=model_seed)
    from .foundation_airport_strong_rule import validate_rule_freeze
    validate_rule_freeze(rule_freeze)
    accepted_path = common.CYCLE / "native029_accepted_contract_001.json"
    accepted = common.read(accepted_path)
    require(accepted["status"] == "accepted_short_native_semantics"
        and common.sha(binary) == accepted["binary"]["sha256"], "accepted_native029")
    data, parent = common.parent_input(seed, fleet)
    require(len(data["jobs"]) == 28506, "complete_28506_offered_population")
    directory = common.CYCLE / name
    require(not directory.exists() and directory.parent == common.CYCLE, "fresh_prospective_run")
    directory.mkdir()
    common.write(directory / "input.json", data)
    from .foundation_airport_calendar_forecast import load_calendar_binding
    binding_reference = None
    if information_variant in ("C10", "C11"):
        common.write(directory / "calendar_binding.json", load_calendar_binding(parent))
        binding_reference = bound(directory / "calendar_binding.json")
    from .foundation_airport_campaign import source_dependency_closure
    paths = list((common.ROOT / "scripts/experiments/g31_ics_circulation").glob("*.py"))
    paths.extend(source_dependency_closure(roots=(MODULE,)).values())
    paths.extend((common.ROOT / "src").rglob("*.py"))
    sources = {}
    for source in sorted(set(paths)):
        relative = source.relative_to(common.ROOT)
        target = directory / "source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        sources[str(relative)] = common.sha(target)
    plan = dict(schema=SCHEMA, name=name, batch=batch, cycle=str(common.CYCLE), output=str(directory),
        parent=parent, information_variant=information_variant, model_seed=model_seed if selected else None,
        training_domain=training_domain if selected else None, selected_model=selected,
        model_freeze=model_freeze, rule_freeze=rule_freeze, grid_freeze=grid_freeze,
        binary=bound(binary), native_acceptance=bound(accepted_path),
        event_budget_calibration=bound(common.CYCLE / "event_budget_calibration_001.json"),
        prepared_gate_historical_directory=str(common.HISTORY / "B2_live_behavior_shadow_003"),
        input={**bound(directory / "input.json"), "semantic_sha256": digest(data)},
        forecast_binding=binding_reference, sources=sources,
        controller=common.CONTROLLER, planner_identity=IDENTITY,
        activate_at=grid["activate_at"], horizon=grid["horizon"], cost_window=grid["cost_window"],
        continuation_version="airport_local_return_analytic_v1", soft_seconds=600, hard_seconds=660,
        outer_seconds=720, event_budget=100000, global_event_budget=data["options"]["max_events"],
        strict_nonharm_certified=False, scope="isolated prospective evaluation; no protected takeover")
    common.write(directory / "plan.json", plan)
    common.event(common.CYCLE, "prepared", name=name, batch=batch,
        plan_sha256=common.sha(directory / "plan.json"), prospective=True)
    return directory


def verify(plan):
    common.verify(plan)
    for key in ("grid_freeze", "rule_freeze"):
        read_bound(plan[key])
    from .foundation_airport_strong_rule import validate_rule_freeze
    validate_rule_freeze(plan["rule_freeze"])
    selected = validate_model_freeze(plan.get("model_freeze"), split=plan["parent"]["split"],
        information_variant=plan["information_variant"], training_domain=plan["training_domain"],
        model_seed=plan["model_seed"])
    require(selected == plan["selected_model"], "frozen_selected_model_unchanged")
    if selected is not None:
        read_bound(selected["checkpoint"])


class AuditStream:
    """One complete current fact per callback, hash chained without retention."""

    def __init__(self, path):
        self.path = Path(path)
        self.raw = self.path.open("xb")
        self.stream = gzip.GzipFile(fileobj=self.raw, mode="wb", compresslevel=1, mtime=0)
        self.count = 0
        self.tail = "0"*64
        self.index = []
        self.timing = []

    def __call__(self, record):
        started = time.perf_counter()
        packet = {key: value for key, value in record.items() if key != "inference_rows"}
        rows = record.get("inference_rows", [])
        if rows:
            packet["inference_parent"] = rows[0]["parent"]
            if "forecast_evidence" in rows[0]:
                packet["forecast_evidence"] = rows[0]["forecast_evidence"]
            shared = {"parent", "observation", "opportunity", "baseline_decision", "forecast_evidence"}
            packet["inference_rows"] = [{k: v for k, v in row.items() if k not in shared} for row in rows]
        packet["audit_sequence"] = self.count
        packet["previous_record_sha256"] = self.tail
        encoded = json.dumps(packet, sort_keys=True, separators=(",", ":"),
            ensure_ascii=False, allow_nan=False).encode("utf8")
        self.tail = hashlib.sha256(encoded).hexdigest()
        self.stream.write(b'{"record_sha256":"'+self.tail.encode()+b'","record":'+encoded+b"}\n")
        self.stream.flush()
        if record.get("opportunity", {}).get("K", 0) > 1:
            opportunity = record["opportunity"]
            tray = opportunity["candidates"][1]["tray_id"]
            chosen = next((r for r in record["chosen_decision"]["intents"] if r["tray_id"] == tray), None)
            baseline = next((r for r in record["baseline_decision"]["intents"] if r["tray_id"] == tray), None)
            self.index.append({"audit_sequence": self.count, "record_sha256": self.tail,
                "owner_id": record["owner_id"], "observed_at": record["observed_at"], "tray_id": tray,
                "selected_action_id": record["selected_action_id"], "baseline_intent": copy.deepcopy(baseline),
                "chosen_intent": copy.deepcopy(chosen), "decision_differs": chosen != baseline})
        self.timing.append((record["planning_wall_ms"], 1000.*(time.perf_counter()-started)))
        self.count += 1

    def close(self):
        self.stream.close()
        self.raw.close()

    def report(self):
        return {"path": str(self.path), "sha256": common.sha(self.path), "records": self.count,
            "tail_record_sha256": self.tail, "storage": "one shared full observation per streamed callback",
            "timings_ms": [{"planning": p, "audit_persistence": a} for p, a in self.timing]}


def read_audit(path):
    previous, count = "0"*64, 0
    with gzip.open(path, "rt", encoding="utf8") as stream:
        for line in stream:
            envelope = json.loads(line)
            record = envelope["record"]
            require(record["audit_sequence"] == count and record["previous_record_sha256"] == previous
                and digest(record) == envelope["record_sha256"], "complete_stream_hash_chain")
            previous = envelope["record_sha256"]
            count += 1
            yield record


def indexed_execution(index, result, client_calls, ack_views):
    """Bind actual requests to unique entity legs with a single receipt scan."""
    calls, acks, legs, transfers, events, loads = defaultdict(list), defaultdict(list), defaultdict(list), {}, defaultdict(list), defaultdict(list)
    for row in client_calls:
        if row.get("kind") == "transfer" and not row.get("retry"):
            request = row["request"]
            calls[(request["owner_id"], row["at"], request["tray_id"])].append(row)
    for owner, view in ack_views.items():
        for row in view.get("delivered_transfer_acks", []):
            acks[(owner, row["request_id"])].append(row)
    tray_indices = {row["tray_id"]: index for index, row in enumerate(result.get("trays", []))}
    for row in result.get("leg_identities", []):
        if row["kind"] == "empty_return":
            identity, separator, suffix = row["transport_leg_id"].rpartition(":empty_return:")
            require(separator and suffix == str(row["runtime_id"]), "native_empty_leg_identity")
            legs[identity].append(row)
    for row in result.get("transfers", []):
        require(row["request_id"] not in transfers, "unique_native_transfer")
        transfers[row["request_id"]] = row
    for number, row in enumerate(result.get("receipts", [])):
        keys = {row.get("transport_leg_id"), row.get("reason")} - {None}
        for key in keys:
            events[key].append((number, row))
        if row["event"] == "LOAD_START":
            loads[row["tray_id"]].append(row)
    for values in loads.values():
        values.sort(key=lambda r: r["time"])
    out = []
    for selection in index:
        attempts = []
        actual = calls[(selection["owner_id"], selection["observed_at"], selection["tray_id"])]
        require(len(actual) <= 1, "one_actual_tray_submission_per_callback")
        for call in actual:
            identity = call["request"]["request_id"]
            intended = selection.get("chosen_intent")
            semantic_keys = ("tray_id", "source", "destination")
            matches = intended is not None and all(call["request"].get(k) == intended.get(k)
                for k in semantic_keys) and call["request"].get("transfer_scope", "cross_zone_transfer") \
                == intended.get("transfer_scope", "cross_zone_transfer")
            def effective_departure(payload):
                values = (payload.get("earliest_departure"), payload.get("message_delay"))
                if any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
                    return None
                return max(values[0], call["at"]+values[1])
            expected_departure = effective_departure(intended) if intended else None
            actual_departure = effective_departure(call["request"])
            matches = bool(matches and expected_departure is not None and expected_departure == actual_departure
                and call["request"]["owner_id"] == selection["owner_id"])
            native_legs = legs[identity]
            require(len(native_legs) <= 1, "unique_actual_empty_leg")
            relevant = dict(events[identity])
            for leg in native_legs:
                relevant.update(events[leg["transport_leg_id"]])
            ev = list(relevant.values())
            native_transfer = transfers.get(identity)
            target_index = tray_indices.get(selection["tray_id"])
            transfer_matches = (native_transfer["tray"] == target_index
                and native_transfer.get("transfer_scope", "cross_zone_transfer")
                == call["request"].get("transfer_scope", "cross_zone_transfer")) \
                if native_transfer is not None and target_index is not None and "tray" in native_transfer else None
            starts = [r for r in ev if r["event"] == "LEG_START"]
            leg_matches = (native_legs[0].get("tray") == target_index and native_legs[0].get("job") == -1
                and len(starts) == 1 and starts[0].get("tray_id") == selection["tray_id"]
                and starts[0].get("from") == call["request"]["source"]
                and starts[0].get("to") == call["request"]["destination"]
                and call["at"] <= starts[0]["time"] <= result["physical_clock"]) \
                if native_legs and target_index is not None and starts and "physical_clock" in result else None
            request_acks = acks[(selection["owner_id"], identity)]
            valid_acks = [r for r in request_acks if
                all(type(r.get(k)) in (int, float) and math.isfinite(r[k])
                    for k in ("observed_at", "delivered_at"))
                and call["at"] <= r["observed_at"] <= r["delivered_at"] <= result.get("physical_clock", -1)]
            first_edge = min((r["time"] for r in ev if r["event"] == "EDGE_ENTER"), default=None)
            received = min((r["time"] for r in ev if r["event"] == "EMPTY_RECEIVED"), default=None)
            future_loads = loads[selection["tray_id"]]
            pos = bisect_left([r["time"] for r in future_loads], received) if received is not None else len(future_loads)
            positive_ack = any(r["status"] in ("granted", "dispatching", "departed", "in_transit", "received")
                for r in valid_acks)
            valid_edge = any(r["event"] == "EDGE_ENTER" and r.get("tray_id") == selection["tray_id"]
                and call["at"] <= r["time"] <= result.get("physical_clock", -1) for r in ev)
            attempts.append({"actual_request": call["request"], "submitted_at": call["at"],
                "selected_intent_matches_actual_submission": matches,
                "expected_effective_departure": expected_departure, "actual_effective_departure": actual_departure,
                "request_matches_native_transfer_entity": transfer_matches,
                "native_leg_matches_entity_and_endpoints": leg_matches,
                "submission_reply": call["reply"], "delivered_acks": request_acks,
                "ack_owner_and_clock_verified_count": len(valid_acks),
                "positive_delivered_ack": positive_ack,
                "complete_G1_execution_chain": matches and transfer_matches is True and leg_matches is True
                    and positive_ack and valid_edge,
                "native_leg": native_legs[0] if native_legs else None,
                "native_transfer_at_export": native_transfer, "first_edge_at": first_edge,
                "received_at": received, "next_load": future_loads[pos] if pos < len(future_loads) else None,
                "rejection_events": [r for r in ev if "REJECT" in r["event"] or "FAIL" in r["event"]]})
        out.append({**selection, "attempts": attempts,
            "actual_submission_observed": bool(attempts), "strict_nonharm_certified": False})
    return {"rows": out, "proposed_decision_differences": sum(r["decision_differs"] for r in out),
        "different_decision_with_actual_submission": sum(r["decision_differs"] and bool(r["attempts"]) for r in out),
        "different_decision_with_unique_leg": sum(r["decision_differs"] and any(
            a["native_leg"] and a["selected_intent_matches_actual_submission"]
            and a["request_matches_native_transfer_entity"] is True
            and a["native_leg_matches_entity_and_endpoints"] is True
            and a["positive_delivered_ack"] for a in r["attempts"]) for r in out),
        "mismatched_actual_submission_count": sum(not a["selected_intent_matches_actual_submission"]
            for r in out for a in r["attempts"]),
        "different_decision_with_complete_G1_chain": sum(r["decision_differs"] and
            any(a["complete_G1_execution_chain"] for a in r["attempts"]) for r in out),
        "strict_nonharm_certified": False}


def worker(plan_path, expected):
    from .native_host import load_native
    from .foundation_airport_protocol_v2 import run_airport_bounded_protocol_control
    from .foundation_airport_calendar_forecast import record_controller_preload
    from .foundation_airport_calendar_prepared import prepare_forecast_provider
    from .foundation_airport_strong_rule import prepare_scorer
    plan = common.read(plan_path)
    output = Path(plan["output"])
    report = {"schema": SCHEMA, "status": "failed_before_native", "native_constructor_attempts": 0}
    started, audit = time.monotonic(), None
    try:
        require(common.sha(plan_path) == expected, "frozen_plan_bytes")
        verify(plan)
        data = read_bound(plan["input"])
        binding = read_bound(plan["forecast_binding"]) if plan["forecast_binding"] else None
        owners = sorted({r["resource_owner"] for r in data["node_contracts"]})
        feature_gate, feature_gate_receipt = None, None
        if plan.get("batch") == "E" and plan["information_variant"] == "C00":
            from .foundation_airport_prepared_callback_gate import make_no_plan_feature_gate
            feature_gate = make_no_plan_feature_gate(output/"actual_prepared_feature_gate",
                episode_id=plan["name"], episode_end=plan["horizon"], minimum_batch_size=3,
                historical_directory=plan["prepared_gate_historical_directory"])
        report["native_constructor_attempts"] = 1
        session = load_native(plan["binary"]["path"]).NativeSession(data)
        receipts = record_controller_preload(binding, session, owners=owners) if binding else {}
        common.write(output / "actual_plan_preload_receipts.json", receipts)
        audit = AuditStream(output / "callback_audit.jsonl.gz")
        forecast_at = prepare_forecast_provider(binding, receipts) if binding else None
        options = dict(parent=plan["parent"], activate_at=plan["activate_at"], forecast_at=forecast_at,
            record_sink=audit, retain_records=False, capture_all_callbacks=True)
        if plan["selected_model"] is not None:
            planner = make_ranker_planner(read_bound(plan["selected_model"]["checkpoint"]), **options)
        else:
            variant = plan["information_variant"]
            planner = make_prospective_planner(policy_id=plan["rule_freeze"]["sha256"]+":"+variant,
                information_variant=variant, selector=prepare_scorer(plan["rule_freeze"]) if variant == "C10" else None,
                **options)
        first_prefix, maximum = None, None
        def precommit(**kwargs):
            nonlocal first_prefix, maximum, feature_gate_receipt
            observation = kwargs["observation"]
            if first_prefix is None and observation["now"] >= plan["activate_at"]:
                controller = {**kwargs["controller_state"], "client": kwargs["client_state"]}
                first_prefix = {"native_state_sha256": session.offline_state_sha256(),
                    "controller_state_sha256": digest(controller), "public_state_digest": digest(observation),
                    "observed_at": observation["now"], "owner_id": observation["owner_id"]}
                first_prefix["complete_prefix_sha256"] = digest(first_prefix)
                common.gz(output / "activation_prefix.json.gz", {"prefix": first_prefix,
                    "controller_state": controller, "observation": observation, "preload_receipts": receipts,
                    "external_context_comparison": "excluded across information variants; preserved separately"})
            decision = kwargs["decision"]
            if maximum is None or len(decision["intents"]) > len(maximum["decision"]["intents"]):
                maximum = {"observation": copy.deepcopy(observation), "decision": copy.deepcopy(decision)}
            if feature_gate is not None and feature_gate_receipt is None:
                feature_gate_receipt = feature_gate(observation=observation, decision=decision,
                    callback_sequence=kwargs["controller_state"]["next_tick"])
        state, calls, segments, final = None, [], [], None
        target = 3600.
        with (output / "progress.jsonl").open("x", encoding="utf8") as progress:
            while True:
                run = run_airport_bounded_protocol_control(session, owners, horizon=target, state=state,
                    event_budget=plan["event_budget"], planner=planner, planner_identity=plan["planner_identity"],
                    precommit_observer=precommit, soft_deadline=started+plan["soft_seconds"], **plan["controller"])
                state = run["controller_state"]
                calls.extend(run["client_calls"])
                if run["result"] is not None:
                    final = run["result"]
                path = output / f"segment_{len(segments):02d}.json.gz"
                common.gz(path, run)
                row = dict(target=target, physical_time=session.physical_time, status=run["status"],
                    elapsed=time.monotonic()-started, raw=str(path),
                    summary=common.summary(data, final, final["physical_clock"]) if final else None)
                segments.append(row)
                progress.write(json.dumps(row)+"\n")
                progress.flush()
                if run["status"] != "reached":
                    report["status"] = "censored_"+run["status"]
                    break
                if session.physical_time >= plan["horizon"]:
                    report["status"] = "complete"
                    break
                target = min(target+3600., plan["horizon"])
        audit.close()
        ack_views = {owner: session.observe_protocol(owner) for owner in owners}
        common.gz(output / "client_calls.json.gz", calls)
        common.gz(output / "final_result.json.gz", final)
        common.gz(output / "ack_views.json.gz", ack_views)
        common.gz(output / "largest_batch.json.gz", maximum)
        if feature_gate is not None:
            gate_status = {
                "attempted": feature_gate_receipt is not None, "receipt": feature_gate_receipt,
                "actual_maximum_batch_size": len(maximum["decision"]["intents"]) if maximum else 0,
                "not_attempted_reason": None if feature_gate_receipt else
                    "no_observed_native_initial_callback_batch_at_least_three",
                "actual_13_candidate_gate_met": bool(feature_gate_receipt and
                    feature_gate_receipt["actual_candidate_count"] >= 13 and
                    feature_gate_receipt["status"] == "passed_actual_current_feature_equivalence"),
                "scope": "offline evaluator gate excluded from controller timing; no model/action changes"}
            if not gate_status["actual_13_candidate_gate_met"]:
                gate_status["actual_13_candidate_unmet_reason"] = (
                    "only actual first qualifying baseline proposals were evaluated; no synthetic expansion to 13")
            common.write(output/"actual_prepared_feature_gate_status.json", gate_status)
            report["actual_prepared_feature_gate"] = gate_status
        common.write(output / "planner_summary.json", planner.report())
        common.write(output / "callback_audit_receipt.json", audit.report())
        if final is not None:
            common.gz(output / "execution_evidence.json.gz", indexed_execution(audit.index, final, calls, ack_views))
        cost = window_cost(data, final, start=plan["cost_window"][0], end=plan["cost_window"][1]) \
            if report["status"] == "complete" else None
        common.write(output / "evaluation.json", {"schema": SCHEMA, "status": report["status"],
            "parent": plan["parent"], "information_variant": plan["information_variant"],
            "input_semantic_sha256": plan["input"]["semantic_sha256"], "cost": cost,
            "activation_prefix": first_prefix, "strict_nonharm_certified": False,
            "incomplete_endpoint_has_advantage": False})
        report.update(final_physical_time=session.physical_time, segments=segments, cost=cost,
            summary=common.summary(data, final, final["physical_clock"]) if final else None,
            activation_prefix=first_prefix, planner_counts=dict(planner.counts),
            final_native_state_sha256=session.offline_state_sha256(), strict_nonharm_certified=False)
        verify(plan)
    except Exception:
        report.update(status="failed", exception=traceback.format_exc())
        if audit is not None and not audit.raw.closed:
            audit.close()
    report["wall_seconds"] = time.monotonic()-started
    import psutil
    process = psutil.Process()
    memory, cpu = process.memory_info(), process.cpu_times()
    report["process_resources"] = {"peak_working_set_bytes": getattr(memory, "peak_wset", memory.rss),
        "cpu_seconds": cpu.user+cpu.system, "concurrency_contract": "at_most_two_native_branches"}
    common.write(output / "worker_report.json", report)
    return report


def launch(directory):
    from .bounded_windows_job import run
    directory = Path(directory).resolve()
    plan = common.read(directory / "plan.json")
    verify(plan)
    cycle = Path(plan["cycle"])
    manifest = common.read(cycle / "manifest.json")
    age = datetime.now(timezone.utc)-datetime.fromisoformat(manifest["created_at"])
    rows = [json.loads(line) for line in (cycle / "ledger.jsonl").read_text().splitlines()]
    require(age.total_seconds() < 16*3600 and sum(r["event"] == "long_native_launch" for r in rows) < 72,
        "registered_native_budget_remaining")
    require(not (directory / "receipt.json").exists(), "fresh_attempt_only")
    token, plan_sha = secrets.token_hex(24), common.sha(directory / "plan.json")
    common.event(cycle, "long_native_launch", name=plan["name"], batch=plan["batch"], plan_sha256=plan_sha)
    with (directory / "stdout.log").open("xb") as stdout, (directory / "stderr.log").open("xb") as stderr:
        process = run([sys.executable, "-m", MODULE, "--worker", str(directory / "plan.json"),
            "--expected", plan_sha, "--admission", token], timeout=plan["hard_seconds"],
            stdout=stdout, stderr=stderr, admission=token, cwd=directory / "source")
    report_path = directory / "worker_report.json"
    report = common.read(report_path) if report_path.exists() else {"status": "unknown_hard_stop"}
    receipt = {"schema": SCHEMA, "process": process, "worker": report, "plan_sha256": plan_sha,
        "status": report["status"]}
    common.write(directory / "receipt.json", receipt)
    common.event(cycle, "long_native_closed", name=plan["name"], status=report["status"],
        wall_seconds=process["wall_seconds"])
    return {"name": plan["name"], "status": report["status"], "wall_seconds": process["wall_seconds"],
        "summary": report.get("summary")}


def compare_runs(reference_directory, candidate_directory):
    """Only compare complete identical-input/source/native/start-prefix runs."""
    directories = [Path(reference_directory), Path(candidate_directory)]
    plans = [common.read(d/"plan.json") for d in directories]
    for plan in plans:
        verify(plan)
    evaluations = [common.read(d/"evaluation.json") for d in directories]
    workers = [common.read(d/"worker_report.json") for d in directories]
    for key in ("parent", "sources", "controller", "planner_identity", "activate_at", "horizon", "cost_window"):
        require(plans[0][key] == plans[1][key], "same_prospective_"+key)
    for key in ("binary", "input", "rule_freeze", "grid_freeze"):
        sha_key = "semantic_sha256" if key == "input" else "sha256"
        require(plans[0][key][sha_key] == plans[1][key][sha_key], "same_prospective_"+key)
    if all(plan["information_variant"] in ("C10", "C11") for plan in plans):
        require(plans[0]["forecast_binding"]["sha256"] == plans[1]["forecast_binding"]["sha256"],
            "same_plan_information_between_plan_variants")
    require(evaluations[0]["activation_prefix"] == evaluations[1]["activation_prefix"], "same_full_warmup_prefix")
    output = {"schema": SCHEMA, "status": "incomplete_not_comparable", "advantage_bag_seconds": None,
        "strict_nonharm_certified": False, "attempts_or_failures_excluded": 0}
    if any(row["status"] != "complete" for row in workers) \
            or any(row["status"] != "complete" or row["cost"] is None for row in evaluations):
        return output
    results = []
    for directory in directories:
        with gzip.open(directory/"final_result.json.gz", "rt") as stream:
            results.append(json.load(stream))
    outcomes = [{r["business_bag_id"]: r["completed_at"] for r in result["jobs"]} for result in results]
    require(set(outcomes[0]) == set(outcomes[1]) and len(outcomes[0]) == 28506, "complete_comparison_population")
    counts, harmed = Counter(), []
    for identity, left in outcomes[0].items():
        right = outcomes[1][identity]
        category = "unknown_incomplete" if left < 0 or right < 0 else \
            "harmed" if right > left else "improved" if right < left else "equal"
        counts[category] += 1
        if category == "harmed":
            harmed.append({"business_bag_id": identity, "reference_completed_at": left,
                "candidate_completed_at": right, "delay_seconds": right-left})
    output.update(status="closed_full_prospective_comparison",
        advantage_bag_seconds=evaluations[0]["cost"]["backlog_integral_bag_seconds"]
            -evaluations[1]["cost"]["backlog_integral_bag_seconds"],
        reference_cost=evaluations[0]["cost"], candidate_cost=evaluations[1]["cost"],
        per_job_comparison_counts=dict(counts), known_harmed_jobs=harmed,
        learning_scope="conditional paired-trained action ranking; multi-step optimal RL not established")
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", type=Path)
    parser.add_argument("--expected")
    parser.add_argument("--admission")
    args = parser.parse_args()
    if args.worker:
        require(args.admission and sys.stdin.readline().strip() == args.admission, "parent_admission_required")
        worker(args.worker, args.expected)
    else:
        parser.error("Use prepare()/launch() from the registered campaign coordinator")


if __name__ == "__main__":
    main()
