"""Run native/Python circulation regressions with explicit binary provenance."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).absolute().parents[3]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot() -> dict[str, str]:
    paths = [ROOT / "CMakeLists.txt", *ROOT.glob("cpp/**/*.hpp"), *ROOT.glob("cpp/**/*.cpp"),
             *ROOT.glob("scripts/experiments/g31_ics_circulation/*.py"),
             *ROOT.glob("tests/test_g31_circulation_*.py"),
             ROOT / "tests/test_g31_fixed_blocking_certificate.py",
             ROOT / "tests/test_g31_original_mechanism.py"]
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=300)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    binary = args.binary.absolute()
    build = json.loads(args.build_receipt.read_text(encoding="utf-8"))
    before = snapshot()
    binary_hash = sha(binary)
    compiled_mismatch = [p for p, digest in build["source_after"].items() if before.get(p) != digest]
    tests = sorted({str(p.relative_to(ROOT)) for p in ROOT.glob("tests/test_g31_circulation_*.py")} |
                   {"tests/test_g31_fixed_blocking_certificate.py",
                    "tests/test_g31_original_mechanism.py"})
    command = [sys.executable, "-m", "pytest", "-q", *tests,
               "--junitxml=" + str((args.output / "junit.xml").absolute()),
               # This newly created campaign owns its temporary directory.
               # Do not depend on a shared Windows Temp pytest root whose
               # permissions may belong to a different execution context.
               "--basetemp=" + str((args.output / "pytest_tmp").absolute())]
    receipt = {"schema": "g31.live_regression.v1", "status": "running", "command": command,
               "binary": str(binary), "binary_sha256": binary_hash,
               "build_receipt": str(args.build_receipt), "build_receipt_sha256": sha(args.build_receipt),
               "compiled_source_mismatch": compiled_mismatch, "source_before": before,
               "test_files": tests, "environment": {"G31_CIRCULATION_BINARY": str(binary),
                    "PYTHONPATH": "src;.", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"}}
    start = time.perf_counter()
    try:
        if build["status"] != "passed" or build["source_changed"] or compiled_mismatch:
            raise RuntimeError("source does not match a successful clean build")
        if binary_hash not in build["binary_sha256"].values():
            raise RuntimeError("binary hash is absent from clean build receipt")
        env = dict(os.environ, **receipt["environment"], PYTHONIOENCODING="utf-8")
        with (args.output / "stdout.log").open("wb") as out, (args.output / "stderr.log").open("wb") as err:
            run = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=err,
                                 timeout=args.timeout, check=False)
        receipt["exit_code"] = run.returncode
        cases = ET.parse(args.output / "junit.xml").findall(".//testcase")
        receipt["counts"] = {"tests": len(cases),
                             "failures": sum(c.find("failure") is not None for c in cases),
                             "errors": sum(c.find("error") is not None for c in cases),
                             "skipped": sum(c.find("skipped") is not None for c in cases)}
        receipt["source_after"] = snapshot()
        receipt["source_changed"] = sorted(k for k in before.keys() | receipt["source_after"].keys()
                                           if before.get(k) != receipt["source_after"].get(k))
        if run.returncode or not cases or any(receipt["counts"][k] for k in ("failures", "errors", "skipped")):
            raise RuntimeError("regression did not complete without failure/error/skip")
        if receipt["source_changed"] or sha(binary) != binary_hash:
            raise RuntimeError("source or binary changed during verification")
        receipt["status"] = "passed"
    except Exception as exc:
        receipt["status"] = "failed"
        receipt["error"] = repr(exc)
    finally:
        receipt["wall_seconds"] = time.perf_counter() - start
        (args.output / "receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps({k: receipt[k] for k in ("status", "counts", "error") if k in receipt}))
    return 0 if receipt["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
