#pragma once

#include "ics_core/runtime/circulation.hpp"

namespace czr005::ics {

// Versioned, deterministic in-process inventory. This is not a deserialize
// interface: only immutable StateCheckpoint objects minted by the runtime may
// restore capabilities. Future environment entries belong in this seal, never
// in an online owner's observation or learned feature vector.
template <typename Writer>
void fingerprint_circulation_state(Writer& w, const CirculationState& s) {
  w.string("czr005.circulation.in_process_checkpoint.v1");
  w.boolean(s.enabled);
  w.u64(s.input.nodes.size());
  for (const auto& n : s.input.nodes) {
    w.i64(n.node); w.string(n.zone); w.i64(n.capacity);
    w.i64(n.export_min_stock); w.boolean(n.allow_export); w.boolean(n.allow_receive);
    w.string(n.control_partition); w.string(n.resource_owner);
  }
  w.u64(s.input.edges.size());
  for (const auto& e : s.input.edges) {
    w.i64(e.from); w.i64(e.to); w.i64(e.capacity); w.floating(e.entry_headway);
  }
  w.u64(s.input.trays.size());
  for (const auto& t : s.input.trays) { w.string(t.tray_id); w.i64(t.node); }
  w.u64(s.input.jobs.size());
  for (const auto& j : s.input.jobs) {
    w.string(j.business_bag_id); w.i64(j.origin); w.i64(j.destination);
    w.floating(j.arrival); w.floating(j.deadline); w.i64(j.storage_node);
    w.floating(j.storage_release_at); w.floating(j.storage_min_dwell);
    w.floating(j.load_seconds); w.floating(j.unload_seconds); w.floating(j.hold_seconds);
    w.boolean(j.protected_service); w.boolean(j.allow_suffix_reroute);
  }
  w.u64(s.input.transfers.size());
  for (const auto& t : s.input.transfers) {
    w.string(t.request_id); w.string(t.tray_id); w.i64(t.source); w.i64(t.destination);
    w.floating(t.issued_at); w.floating(t.message_delay); w.floating(t.earliest_departure);
    w.floating(t.expiry);
  }
  w.u64(s.trays.size());
  for (const auto& t : s.trays) {
    w.string(t.tray_id); w.i64(t.node); w.string(t.mode); w.i64(t.job);
    w.i64(t.active_leg); w.i64(t.edge_from); w.i64(t.edge_to); w.i64(t.reception_node);
    w.i64(t.transfer); w.floating(t.available_at); w.floating(t.storage_arrived_at);
    w.u64(t.generation); w.u64(t.traversal_id); w.u64(t.public_traversal_version); w.boolean(t.edge_entry_observed);
  }
  w.u64(s.jobs.size());
  for (const auto& j : s.jobs) {
    w.string(j.status); w.i64(j.tray); w.floating(j.loaded_at);
    w.floating(j.storage_entered_at); w.floating(j.storage_released_at);
    w.floating(j.completed_at); w.boolean(j.deadline_met);
  }
  w.u64(s.transfers.size());
  for (const auto& t : s.transfers) {
    w.string(t.status); w.string(t.reason); w.i64(t.tray);
    w.floating(t.delivered_at); w.floating(t.departed_at); w.floating(t.received_at);
  }
  w.u64(s.legs.size());
  for (const auto& l : s.legs) {
    w.i64(l.runtime_id); w.string(l.transport_leg_id); w.i64(l.tray);
    w.i64(l.job); w.string(l.kind);
  }
  w.u64(s.receipts.size());
  for (const auto& r : s.receipts) {
    w.floating(r.time); w.string(r.event); w.string(r.business_bag_id);
    w.string(r.transport_leg_id); w.string(r.tray_id); w.u64(r.traversal_id);
    w.i64(r.node); w.i64(r.from); w.i64(r.to); w.string(r.reason);
  }
  w.u64(s.next_entry.size());
  for (double t : s.next_entry) w.floating(t);
  w.u64(s.next_traversal);
  w.u64(s.route_intents.size());
  for (const auto& r : s.route_intents) {
    w.string(r.request_id); w.string(r.owner_id); w.string(r.business_bag_id); w.string(r.tray_id);
    w.i64(r.from); w.i64(r.next); w.u64(r.expected_generation); w.u64(r.expected_traversal);
    w.floating(r.delivered_at); w.floating(r.expiry); w.string(r.status); w.string(r.reason);
  }
  w.u64(s.demand_messages.size());
  for (const auto& m : s.demand_messages) {
    w.string(m.message_id); w.string(m.source_owner); w.string(m.target_owner);
    w.u64(m.publication_sequence);
    w.floating(m.observed_at); w.floating(m.delivered_at); w.boolean(m.delivered);
    w.u64(m.jobs.size());
    for (const auto& j : m.jobs) {
      w.string(j.business_bag_id); w.i64(j.origin); w.floating(j.arrival); w.floating(j.deadline);
    }
  }
  w.u64(s.next_control_id);
  w.u64(s.next_channel_message_id.size());
  for(const auto& [channel,next]:s.next_channel_message_id) {
    w.string(channel.first);w.string(channel.second);w.u64(next);
  }
  w.u64(s.service_forecasts.size());
  for (const auto& m : s.service_forecasts) {
    w.string(m.message_id); w.string(m.source_owner); w.string(m.target_owner);
    w.string(m.business_bag_id); w.string(m.tray_id); w.i64(m.from); w.i64(m.next);
    w.u64(m.generation); w.u64(m.traversal_id);
    w.u64(m.publication_sequence);
    w.floating(m.observed_at); w.floating(m.delivered_at);
    w.floating(m.entry_estimate); w.floating(m.release_estimate);
    w.string(m.status); w.string(m.supersedes); w.boolean(m.delivered);
  }
  w.u64(s.recovery_intents.size());
  for(const auto& r:s.recovery_intents) {
    w.string(r.request_id); w.string(r.owner_id); w.string(r.tray_id);
    w.u64(r.expected_generation); w.floating(r.delivered_at);
    w.string(r.status); w.string(r.reason);
  }
  w.string(s.static_domain_version);
  w.u64(s.static_route_potential.size());
  for(const auto& row:s.static_route_potential) {
    w.u64(row.size()); for(double value:row) w.floating(value);
  }
  w.u64(s.static_route_reachable.size());
  for(const auto& row:s.static_route_reachable) {
    w.u64(row.size()); for(bool value:row) w.boolean(value);
  }
  w.u64(s.resource_waits.size());
  for(const auto& [id,wait]:s.resource_waits) {
    w.i64(id); w.i64(wait.runtime_id); w.i64(wait.node); w.u64(wait.generation);
    w.u64(wait.edge_indices.size()); for(int edge:wait.edge_indices) w.i64(edge);
    w.u64(wait.receiving_nodes.size()); for(int node:wait.receiving_nodes) w.i64(node);
    w.u64(wait.ranking_nodes.size()); for(int node:wait.ranking_nodes) w.i64(node);
    w.boolean(wait.static_blocked);
  }
  const auto write_wait_index=[&](const auto& index) {
    w.u64(index.size());
    for(const auto& [resource,waiters]:index) {
      w.i64(resource); w.u64(waiters.size());
      for(const auto& [id,generation]:waiters) { w.i64(id); w.u64(generation); }
    }
  };
  write_wait_index(s.edge_waiters); write_wait_index(s.receiving_waiters);
  write_wait_index(s.ranking_waiters);
  w.u64(s.next_resource_wait_generation);
}

}  // namespace czr005::ics
