#pragma once

// Included inside the binding translation unit's private namespace.
class NativeSession {
 public:
  explicit NativeSession(const py::dict& data) {
    auto host=parse_host(data,"circulation");
    graph_=std::move(host.graph);config_=std::move(host.config);
    // A session default is public and independent of the future arrival tape.
    if(config_.max_simulation_time<0) config_.max_simulation_time=1.0e9;
    runtime_=std::make_unique<EventDrivenJunctionRuntime>(graph_,config_);
    runtime_->initialize_circulation(read_input(data),host.faults);
  }
  NativeSession(const Graph& graph,const EventDrivenJunctionConfig& config)
      :graph_(graph),config_(config),runtime_(std::make_unique<EventDrivenJunctionRuntime>(graph_,config_)) {}
  double physical_time() const {return runtime_->progress_snapshot().simulated_time;}
  bool step() {return runtime_->process_one_event();}
  py::dict advance_to(double time,int budget=1000000) {
    const auto start=std::chrono::steady_clock::now();
    const int count=runtime_->advance_circulation_to(time,budget);
    py::dict out;out["physical_time"]=physical_time();out["processed_events"]=count;
    // Reaching the numeric clock is insufficient: a budget may stop between
    // same-timestamp native microphases. Consult only inside the scheduler;
    // the next private event time never becomes an online policy feature.
    const auto next=runtime_->next_physical_event_time();
    const bool complete=physical_time()>=time && (!next || *next>time);
    out["status"]=complete ? "reached" : "budget_exhausted";
    out["horizon_complete"]=complete;
    out["wall_seconds"]=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    return out;
  }
  EventDrivenJunctionRuntime::StateCheckpoint checkpoint() const {return runtime_->capture_state_checkpoint();}
  void restore(const EventDrivenJunctionRuntime::StateCheckpoint& state) {runtime_->restore_state_checkpoint(state);}
  std::shared_ptr<NativeSession> fork() const {
    auto branch=std::make_shared<NativeSession>(graph_,config_);
    branch->restore(checkpoint());
    return branch;
  }
  std::string offline_state_sha256() const {return runtime_->circulation_state_sha256();}
  py::dict result_at(double horizon) {
    auto progress=advance_to(horizon);
    auto out=render_result(*runtime_,"circulation",{},false);
    out["schema"]="g31.circulation.live_result.v1";
    out["horizon"]=horizon;out["advance"]=progress;
    out["scope"]="offline result; contains offered population, never an online observation";
    const auto& s=runtime_->circulation_state();
    int offered=0,observed=0,loaded=0,completed=0;
    for(std::size_t i=0;i<s.jobs.size();++i) {
      offered+=s.input.jobs[i].arrival<=horizon;
      observed+=s.jobs[i].status!="unreleased";
      loaded+=s.jobs[i].loaded_at>=0;
      completed+=s.jobs[i].completed_at>=0;
    }
    py::dict totals;totals["offered_by_horizon"]=offered;totals["observed"]=observed;
    totals["loaded"]=loaded;totals["completed"]=completed;out["population"]=totals;
    return out;
  }
  py::dict observe(const std::string& owner) const {
    if(runtime_->phase()==EventDrivenJunctionRuntimePhase::kIdle)
      throw py::value_error("circulation:live_session_required");
    const auto& s=runtime_->circulation_state();
    bool exists=false;
    for(const auto& n:s.input.nodes) exists=exists||s.owner(n.node)==owner;
    if(!exists) throw py::value_error("circulation:unknown_observation_owner");
    py::dict out;out["schema"]="g31.regional_observation.v1";out["now"]=physical_time();out["owner_id"]=owner;
    out["version"]=owner_version(owner);
    py::list nodes,edges,contracts,edge_contracts,trays,jobs,transfers,messages,faults,routes,recoveries;
    for(int id:graph_.node_locations()) {
      const auto& n=graph_.node(id);
      nodes.append(py::make_tuple(n.location,n.node_type,n.service_time,n.x,n.y,n.outgoing));
    }
    for(const auto& e:s.input.edges) {
      const auto& physical=graph_.edge(e.from,e.to);
      edges.append(py::make_tuple(e.from,e.to,physical.length,physical.speed));
      py::dict d;d["from"]=e.from;d["to"]=e.to;d["capacity"]=e.capacity;d["entry_headway"]=e.entry_headway;
      edge_contracts.append(d);
    }
    for(const auto& n:s.input.nodes) {
      py::dict d;d["node"]=n.node;d["zone"]=n.zone;d["logistics_zone"]=n.zone;
      d["control_partition"]=s.partition(n.node);d["resource_owner"]=s.owner(n.node);
      d["capacity"]=n.capacity;d["export_min_stock"]=n.export_min_stock;
      d["allow_export"]=n.allow_export;d["allow_receive"]=n.allow_receive;
      if(s.owner(n.node)==owner) {d["occupancy"]=s.occupancy(n.node);d["actual_available"]=s.empty_stock(n.node,physical_time());}
      contracts.append(d);
    }
    std::set<int> visible_jobs;
    for(const auto& t:s.trays) {
      if(s.owner(t.node)!=owner) continue;
      py::dict d;d["tray_id"]=t.tray_id;d["node"]=t.node;d["mode"]=t.mode;
      d["edge_from"]=t.edge_from;d["edge_to"]=t.edge_to;d["available_at"]=t.available_at;
      d["reception_node"]=t.reception_node;d["generation"]=t.generation;d["traversal_id"]=t.public_traversal_version;
      d["business_bag_id"]=t.job>=0 ? s.input.jobs[t.job].business_bag_id : "";
      py::list prefix;
      if(t.active_leg>=0) {
        const auto& leg=s.legs[t.active_leg];
        for(const auto& r:s.receipts) {
          if(r.transport_leg_id!=leg.transport_leg_id) continue;
          if(r.event=="LEG_START") prefix.append(r.from);
          else if(r.event=="EDGE_EXIT") prefix.append(r.to);
        }
      }
      if(py::len(prefix)==0) prefix.append(t.node);
      d["committed_prefix"]=prefix;
      if(t.job>=0) visible_jobs.insert(t.job);
      // Known deterministic operation durations come from observed starts, not
      // inspection of queued future completion events.
      for(auto it=s.receipts.rbegin();it!=s.receipts.rend();++it) {
        if(it->tray_id!=t.tray_id) continue;
        if(t.edge_to>=0 && it->event=="EDGE_ENTER" && it->traversal_id==t.traversal_id) {
          d["edge_exit_at"]=it->time+std::max(graph_.edge(it->from,it->to).travel_time(),runtime_->circulation_minimum_service_seconds());
          break;
        }
        if(t.job>=0 && t.mode=="loading" && it->event=="LOAD_START") {
          d["available_at"]=it->time+s.input.jobs[t.job].load_seconds;break;
        }
        if(t.job>=0 && t.mode=="unloading" && it->event=="UNLOAD_START") {
          d["available_at"]=it->time+s.input.jobs[t.job].unload_seconds;break;
        }
      }
      trays.append(d);
    }
    for(std::size_t i=0;i<s.jobs.size();++i) {
      const auto& j=s.input.jobs[i];const auto& state=s.jobs[i];
      if(state.status=="unreleased") continue;
      if(s.owner(j.origin)!=owner && !visible_jobs.count(static_cast<int>(i))) continue;
      py::dict d;
#define JFIELD(name) d[#name]=j.name
      JFIELD(business_bag_id);JFIELD(origin);JFIELD(destination);JFIELD(arrival);JFIELD(deadline);
      JFIELD(storage_node);JFIELD(storage_release_at);JFIELD(storage_min_dwell);JFIELD(load_seconds);
      JFIELD(unload_seconds);JFIELD(hold_seconds);JFIELD(protected_service);JFIELD(allow_suffix_reroute);
#undef JFIELD
      d["status"]=state.status;d["storage_entered_at"]=state.storage_entered_at;
      d["storage_released_at"]=state.storage_released_at;d["loaded_at"]=state.loaded_at;
      // Origin may retain its published contract, but not remote live progress.
      if(!visible_jobs.count(static_cast<int>(i)) && state.tray>=0 && s.owner(s.trays[state.tray].node)!=owner) {
        d["status"]="handed_off";d["storage_entered_at"]=-1;d["storage_released_at"]=-1;
      }
      jobs.append(d);
    }
    for(std::size_t i=0;i<s.transfers.size();++i) {
      const auto& request=s.input.transfers[i];const auto& state=s.transfers[i];
      // No preloaded future transfer is visible before issue or delivery.
      if(request.issued_at>physical_time() ||
          (s.owner(request.source)!=owner && !(state.delivered_at>=0 && s.owner(request.destination)==owner))) continue;
      py::dict d;
#define TFIELD(name) d[#name]=request.name
      TFIELD(request_id);TFIELD(tray_id);TFIELD(source);TFIELD(destination);TFIELD(issued_at);
      TFIELD(earliest_departure);TFIELD(expiry);
#undef TFIELD
      d["status"]=state.status;d["reason"]=state.reason;
      d["delivered_at"]=state.delivered_at;d["departed_at"]=state.departed_at;d["received_at"]=state.received_at;
      transfers.append(d);
    }
    // A demand publication replaces its channel snapshot. Keep the complete
    // out-of-order delivery history offline, not in every online observation.
    std::map<std::string,const CirculationDemandMessage*> latest_demand;
    for(const auto& message:s.demand_messages) {
      if(!message.delivered || message.target_owner!=owner) continue;
      auto& latest=latest_demand[message.source_owner];
      if(!latest || std::tie(message.observed_at,message.publication_sequence)>
                    std::tie(latest->observed_at,latest->publication_sequence)) latest=&message;
    }
    for(const auto& [source,latest]:latest_demand) {
      const auto& message=*latest;
      py::dict d;d["kind"]="demand";d["message_id"]=message.message_id;
      d["source_owner"]=message.source_owner;d["target_owner"]=message.target_owner;
      d["publication_sequence"]=message.publication_sequence;
      d["observed_at"]=message.observed_at;d["delivered_at"]=message.delivered_at;
      py::list queue;
      for(const auto& j:message.jobs) {
        py::dict item;item["business_bag_id"]=j.business_bag_id;item["origin"]=j.origin;
        item["arrival"]=j.arrival;item["deadline"]=j.deadline;item["status"]="waiting_for_tray";queue.append(item);
      }
      d["jobs"]=queue;messages.append(d);
    }
    for(const auto& message:s.service_forecasts) {
      if(!message.delivered || message.target_owner!=owner) continue;
      py::dict d;d["kind"]="service_forecast";
#define SFIELD(name) d[#name]=message.name
      SFIELD(message_id);SFIELD(source_owner);SFIELD(target_owner);SFIELD(business_bag_id);SFIELD(tray_id);
      SFIELD(from);SFIELD(next);SFIELD(generation);SFIELD(traversal_id);SFIELD(observed_at);SFIELD(delivered_at);
      SFIELD(entry_estimate);SFIELD(release_estimate);SFIELD(status);
      SFIELD(publication_sequence);SFIELD(supersedes);
#undef SFIELD
      d["estimate_scope"]="next_node_service_completion";
      messages.append(d);
    }
    for(const auto& [from,to,active,received]:runtime_->circulation_known_faults(owner)) {
      py::dict d;d["from"]=from;d["to"]=to;d["active"]=active;d["received_at"]=received;faults.append(d);
    }
    for(const auto& request:s.route_intents) {
      if(request.owner_id!=owner) continue;
      py::dict d;d["request_id"]=request.request_id;d["status"]=request.status;d["reason"]=request.reason;
      routes.append(d);
    }
    for(const auto& request:s.recovery_intents) {
      if(request.owner_id!=owner) continue;
      py::dict d;d["request_id"]=request.request_id;d["status"]=request.status;d["reason"]=request.reason;
      recoveries.append(d);
    }
    out["node_records"]=nodes;out["edge_records"]=edges;out["node_contracts"]=contracts;
    out["edge_contracts"]=edge_contracts;out["trays"]=trays;out["jobs"]=jobs;
    out["transfers"]=transfers;out["delivered_messages"]=messages;out["known_faults"]=faults;out["route_requests"]=routes;
    out["recovery_requests"]=recoveries;
    return out;
  }
  py::dict submit_transfer(const py::dict& d) {
    const auto owner=required<std::string>(d,"owner_id");
    if(d.contains("expected_version") && required<std::uint64_t>(d,"expected_version")!=owner_version(owner))
      return reply("rejected:stale_observation");
    CirculationTransfer request;
    request.request_id=required<std::string>(d,"request_id");request.tray_id=required<std::string>(d,"tray_id");
    request.source=required<int>(d,"source");request.destination=required<int>(d,"destination");
    request.message_delay=field<double>(d,"message_delay",0);
    request.earliest_departure=field<double>(d,"earliest_departure",physical_time());
    request.expiry=required<double>(d,"expiry");
    return reply(runtime_->submit_circulation_transfer(request,owner));
  }
  py::dict submit_route(const py::dict& d) {
    CirculationRouteIntent request;
    request.request_id=required<std::string>(d,"request_id");request.owner_id=required<std::string>(d,"owner_id");
    request.business_bag_id=required<std::string>(d,"business_bag_id");request.tray_id=required<std::string>(d,"tray_id");
    request.from=required<int>(d,"from");request.next=required<int>(d,"next");
    request.expected_generation=required<std::uint64_t>(d,"expected_generation");
    request.expected_traversal=field<std::uint64_t>(d,"expected_traversal",0);request.expiry=required<double>(d,"expiry");
    return reply(runtime_->submit_circulation_route(request,field<double>(d,"message_delay",0)));
  }
  py::dict cancel_transfer(const std::string& id,const std::string& owner) {return reply(runtime_->cancel_circulation_transfer(id,owner));}
  py::dict recover_empty(const std::string& id,const std::string& owner,const std::string& tray,double delay) {
    CirculationRecoveryIntent request;request.request_id=id;request.owner_id=owner;request.tray_id=tray;
    return reply(runtime_->request_circulation_empty_recovery(request,delay));
  }
  py::dict publish_demand(const std::string& from,const std::string& to,double delay) {return reply(runtime_->publish_circulation_demand(from,to,delay));}
  py::dict publish_service_forecast(const std::string& from,const std::string& to,
                                   const std::string& tray,int next,double delay) {
    auto result=reply(runtime_->publish_circulation_service_forecast(from,to,tray,next,delay));
    if(py::cast<std::string>(result["status"])=="pending")
      result["message_id"]=runtime_->circulation_state().service_forecasts.back().message_id;
    return result;
  }
  py::dict withdraw_service_forecast(const std::string& source,const std::string& id,double delay) {
    auto result=reply(runtime_->withdraw_circulation_service_forecast(source,id,delay));
    if(py::cast<std::string>(result["status"])=="pending")
      result["message_id"]=runtime_->circulation_state().service_forecasts.back().message_id;
    return result;
  }
  py::dict offline_diagnostics() const {
    py::list junctions,waits,trays,legs;
    // The runtime method rejects Idle and staged transactions before reading.
    for(const auto& row:runtime_->circulation_offline_junctions()) {
      py::dict d;d["node"]=row.node;d["queue"]=row.queue;d["source_queue"]=row.source_queue;
      d["scheduled_incoming"]=row.scheduled_incoming;d["next_dispatch_time"]=row.next_dispatch_time;
      junctions.append(d);
    }
    const auto& s=runtime_->circulation_state();
    for(const auto& [id,w]:s.resource_waits) {
      py::dict d;d["runtime_id"]=id;d["node"]=w.node;d["generation"]=w.generation;
      d["edge_indices"]=w.edge_indices;d["receiving_nodes"]=w.receiving_nodes;
      d["ranking_nodes"]=w.ranking_nodes;d["static_blocked"]=w.static_blocked;waits.append(d);
    }
    for(const auto& t:s.trays) {
      py::dict d;d["tray_id"]=t.tray_id;d["node"]=t.node;d["mode"]=t.mode;
      d["active_leg"]=t.active_leg;d["job_index"]=t.job;d["transfer_index"]=t.transfer;
      d["edge_from"]=t.edge_from;d["edge_to"]=t.edge_to;d["reception_node"]=t.reception_node;
      d["internal_traversal_id"]=t.traversal_id;d["public_traversal_version"]=t.public_traversal_version;
      trays.append(d);
    }
    for(const auto& leg:s.legs) {
      py::dict d;d["runtime_id"]=leg.runtime_id;d["transport_leg_id"]=leg.transport_leg_id;
      d["tray_index"]=leg.tray;d["job_index"]=leg.job;d["kind"]=leg.kind;legs.append(d);
    }
    py::dict out;out["schema"]="g31.circulation.offline_diagnostics.v1";
    out["scope"]="offline audit only; contains remote current state and internal IDs, never online policy features";
    out["now"]=physical_time();out["junctions"]=junctions;out["resource_waits"]=waits;
    out["edge_waiters"]=s.edge_waiters;out["receiving_waiters"]=s.receiving_waiters;
    out["ranking_waiters"]=s.ranking_waiters;out["trays"]=trays;out["legs"]=legs;
    return out;
  }
 private:
  Graph graph_;
  EventDrivenJunctionConfig config_;
  std::unique_ptr<EventDrivenJunctionRuntime> runtime_;
  std::uint64_t owner_version(const std::string& owner) const {
    const auto& s=runtime_->circulation_state();std::uint64_t version=0;
    for(const auto& r:s.receipts)
      if((r.node>=0 && s.owner(r.node)==owner) || (r.from>=0 && s.owner(r.from)==owner)) ++version;
    for(const auto& m:s.demand_messages) if(m.delivered && m.target_owner==owner) ++version;
    for(const auto& m:s.service_forecasts) if(m.delivered && m.target_owner==owner) ++version;
    return version;
  }
  static py::dict reply(const std::string& response) {
    const auto separator=response.find(':');py::dict d;
    d["status"]=response.substr(0,separator);d["reason"]=separator==std::string::npos ? "" : response.substr(separator+1);
    return d;
  }
};

void bind_session(py::module_& module) {
  py::class_<EventDrivenJunctionRuntime::StateCheckpoint>(module,"NativeCheckpoint")
    .def_property_readonly("offline_state_sha256",&EventDrivenJunctionRuntime::StateCheckpoint::state_sha256);
  py::class_<NativeSession,std::shared_ptr<NativeSession>>(module,"NativeSession")
    .def(py::init<const py::dict&>())
    .def_property_readonly("physical_time",&NativeSession::physical_time)
    .def("step",&NativeSession::step)
    .def("advance_to",&NativeSession::advance_to,py::arg("time"),py::arg("max_events")=1000000)
    .def("observe",&NativeSession::observe)
    .def("checkpoint",&NativeSession::checkpoint).def("restore",&NativeSession::restore)
    .def("fork",&NativeSession::fork).def("offline_state_sha256",&NativeSession::offline_state_sha256)
    .def("submit_transfer_intent",&NativeSession::submit_transfer)
    .def("submit_route_intent",&NativeSession::submit_route)
    .def("cancel_transfer_intent",&NativeSession::cancel_transfer)
    .def("recover_empty_tray",&NativeSession::recover_empty,py::arg("request_id"),py::arg("owner_id"),py::arg("tray_id"),py::arg("delay")=0)
    .def("publish_demand",&NativeSession::publish_demand,py::arg("source_owner"),py::arg("target_owner"),py::arg("delay")=0)
    .def("publish_service_forecast",&NativeSession::publish_service_forecast,
         py::arg("source_owner"),py::arg("target_owner"),py::arg("tray_id"),py::arg("next_node"),py::arg("delay")=0)
    .def("withdraw_service_forecast",&NativeSession::withdraw_service_forecast,
         py::arg("source_owner"),py::arg("original_message_id"),py::arg("delay")=0)
    .def("offline_diagnostics",&NativeSession::offline_diagnostics)
    .def("result_at",&NativeSession::result_at);
}
