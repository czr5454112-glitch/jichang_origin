# LT-1 实施记录：真实宿主、在线控制、强参考与原图反证

本记录从已经完成的 `codex/g31-ics-v3-circulation` 工作区继续，参照长期包，不回滚、不再次导入 V3。工作树 HEAD 仍为成熟 G31 `46cc46ab6bc121628fd6357e9f3c7636745fd732`；本轮源码未提交、未推送。旧结果及修复前失败全部保留。下面的工程通过不等于 P1–P7 全部完成。

完整阅读的总纲、起点说明和发送说明在 `docs/external_review/g31_ics_long_term_20261013/`；ZIP SHA256 为 `b1d5a52669da364dde2f64085e5cf51917f0c0ce32097b132d993efefc61a3e1`。唯一核验起点的 P0 对照包含旧交付24份实现及54份编译来源身份，未重复冒称旧1580项测试由本轮重新运行。

## 实际实现与验证范围

- `NativeSession` 持续推进成熟 G31 的唯一事件堆，支持异步区域请求、实时生成空盘意图、合法需求/服务预测消息、真实资源变化唤醒、checkpoint/restore/fork。完整状态与离线诊断不进入在线 owner 观察。
- 完整 circulation 状态与既有 J2/P2 能力、源/合流队列、头距、故障真值/已通知状态、结果分母共同捕获。checkpoint 只支持声明的安全事件边界，未声称支持任意事务中断或不可信对象文件反序列化。
- 区分物流区、控制分区、资源 owner。R1 的公开 A* 编解码保留真实已执行前缀、Storage 阶段和可替换后缀；异步交付时再次检查权限、版本、当前阶段合法后缀和已通知故障。S4 仍逐跳决定、原生 shield/JIT/P2 仍执行。
- R2 从 owner 观察和合法已送达消息生成请求，初始 `transfers=[]`。actual / firm / conditional 三种供给不混为现货。普通解析匹配、终点腾位、已公开条件服务窗口是强基线，均不宣称创新。
- 预测撤销通过原生延迟 tombstone 传递，可先于原快照到达；它只撤软预测，不能取消已出发托盘或接收义务。
- `live:` 在线请求命名空间与环境回放隔离；公开消息序号按通信通道分配，公开 traversal 版本按 tray 分配。内部全局 traversal 审计身份仍保留。修复前的两个跨 owner 计数泄漏有真实执行回执；未来请求 ID 问题只保留静态发现与实际修后证据，不补造不存在的修前日志。

当前稳定 native 构建是 `p1_build_006`，二进制位于 `build_lt_session_006/python/czr005_circulation.cp311-win_amd64.pyd`，SHA256：

`0bdd31835d8e9b7269bb2d45e14484054aad73abf3a10dc989f3574230b16190`

`live_validation_002` 实际记录146项通过、0失败/错误/跳过，且源与二进制身份绑定。随后 Python 解析控制开销优化如有变化，须另跑新回执，不能挪用该通过。`p1_checkpoint_validation_004` 对005源码实编专项，611个安全事件边界各做两个真实继续分支，并检查预测撤销等新增状态。`native_compat_001` 在其冻结源码上17/17 CTest通过；后续改动另有定向专项，不将该17项标签移植到新源码。`legacy_parity_002` 实际重跑固定成熟基线和当轮源码，无故障/故障两场共10类确定性输出相同。

最终006构建及源码绑定的 `live_validation_003` 实际 **180项通过，0失败/错误/跳过，source_changed=[]**。该次包含新增同H完成性、有限参考删失、原图阻塞证书和事前选样回归。`p1_checkpoint_validation_005` 再次实编通过611边界专项；不是把旧版本测试数量重贴到006。

## 实际失败与修正

| 发现 | 修前证据 | 修正及边界 |
|---|---|---|
| 路由偏好被原 scorer 覆写 | `p1_session_dev_001` | 在 scorer 之后应用已授权偏好，仍受 shield 和执行前缀限制 |
| 静态零容量域仍沿旧势走不可用捷径 | `static_closed_domain_before_*`、早期原图运行 | 在声明的零容量关闭合同中建立公共合法域，不改图方向/边数；零容量的现场含义仍未知 |
| 长等待仍由末尾兜底和首选路径规则重复轮询 | `p2_recovery_before_001`、`p2_preferred_wait_before_001` | 依赖真实容量/头距/队列变化唤醒；保留成熟 S3/S4 与 FIFO 权限。单出口不需要排名唤醒，发现回归后保留原断言修复 |
| 已知死后缀、已通知故障错误返回 updated | `p3_route_invalid_before_001` 两项真实失败 | 检查当前运输阶段目标与已收到故障，准确拒绝 |
| 有限参考把提交 pending 后的拒绝当可行动作 | 早期有限参考及专项反例 | 读取实际终态；异步拒绝保留原结果但排除可行动作，未解析/预算状态保持 unknown |
| 全局消息/运输序号泄漏不相关 owner 活动 | `private_message_counter_before_001`、`private_traversal_counter_before_001` | 改局部通道/实体版本，三个 `--require-fixed` 探针在005通过 |
| 有限参考把未到H的控制续跑当最优 | `analytic_independent_review_001/censored_continuation_receipt.json`：目标20，实际0.1，却认证最优 | 校验请求H、结果H、分支/结果/推进时钟及明确的完成标志，保留外层/内层删失；前缀物理审计不能替代完整性 |
| native时钟到H但同H还有未执行事件 | `same_timestamp_budget_before_002.json`：已报reached，继续同H又执行8事件 | 006内部检查所有到期事件已排空，返回horizon_complete；不向策略暴露未来事件堆；刚好用满预算但确已完成的正控制仍通过 |

全部原件根目录为 `outputs/experiments/g31_ics_long_term_20261013/`。`RESULT_INDEX.jsonl` 为结果导航；不能以一场 `passed` 推断另一个物理合同通过。

## 原图和完整源：保留负结果，纠正语义过度解释

源表核验得到151节点、227有向边；1×完整28506袋、2×完整57012袋，保留父身份与既有增密规则。完整任务带只属环境；策略看不到未来任务数和到达带。

源表 F1 为“托盘容量（个）”，97→98 的 F7=0 是原数值；全部227条边恰好符合 `floor(length/2m)`。旧成熟 adapter 仅把容量保留为 metadata。因此 **原值0已确认，但“0意味着物理封闭”未获现场确认**。本轮保守 native 合同仍按关闭处理；没有擅自改成1。短连接零缓存、两端接管/尾窗的另一种物理合同尚未实现，不能拿一个推测解释把原失败改写成成功。

`p2_original_1x_live_s4_002` 在当前保守合同下真正到 H=86400：30877事件，28506全部观察，22装载、0业务完成，独立工序/盘守恒/容量审计通过。005的 `p2_original_offline005_001` 又输出精确原生队列：Storage53队列 `[22,23,24,25]` 对应袋0→99、袋2→116、袋1→99、袋3→47；队首22无正容量后缀，后面有可达业务仍被FIFO挡住。Storage在19500确实释放过4盘，不能把它们统称为尚未释放或全部不可达。

其余实际等待链为29/137/150/139→112→53，以及136→137；当前证据是无环的链式回堵，不是证明存在循环死锁。不能取消头袋、允许越过固定 FIFO、删掉4001个静态不可达业务或扩盘来伪造完成。

004同H=21600的1×/2×反应与预测四组均真实执行，完整输入都在分母：1×观察3485袋，18装载、0完成，6次导出/2次接收；2×观察6449袋，17装载、0完成，6次导出/1次接收。预测请求更多，逐袋受限耗时却相同。该组无业务收益，不据此删除区域自治或预测预平衡需求。

合法往返机制组按事前静态条件从原母流选择，使用完整原图、真实任务到达/目的地/Storage，单盘为单独库存因子；它不是完整运营流，也不能取代以上全流负结果。选样规则与被排除任务数量必须随结果一同交付。

`p2_original_mechanism_2_005_001` 的两个原源业务均由 `initial:26:0` 真正完成，中间一次真实跨区返回，反应与预测成本相同。相同事前规则扩至24件的 `p2_original_mechanism_24_005_001`，两法均24/24完成、23次真实返供received，同盘身份贯穿。预测总 arrival→unload 耗时418514.272581→414198.867581秒，约1.031%改善，逐件不恶化；但两法均 **19件逾期，仅5件按时**，不能称业务质量达标。完整151/227图、边方向和容量未改；母流28506件中10320件满足静态往返条件，再取首个合格loader的前24件，不按模拟胜负挑选。可读逐盘/逐业务事件账为该目录的 `actual_same_tray_event_table.md`，JSON保留运输段ID。

全流的 `p2_original_offline005_001/fixed_contract_blocking_certificate.json` 给出13项实际充分条件：队首独立BFS不可达、Storage4盘占满且固定FIFO覆盖全部占用、其余18盘都需要进入该库、真实接收依赖链终结于此、无空盘/在途盘/接收租约/可恢复隔离盘。仅证明固定FIFO、on-carrier、零边关闭且禁止撤任务卸盘的当前状态不能再完成服务，不是机场全局最优或现场不可行证明。

另新增并实算独立单盘FIFO乐观下界 `single_tray_lower_bound.py`。保留真实有向正容量最短旅行、Storage绝对释放/最小驻留、装卸及hold，放松所有非负节点服务/拥塞/头距/消息等待；限定唯一盘、同一FIFO loader、不同到达时刻且全24件仍在总体。`p4_single_tray_lower_bound_006_002` 对机制组两法及原图返供参考六支，共八组各1210条traversal重新审计，实际同盘加载顺序均符合下界适用前提。受限耗时下界395187.971581秒，必然最终逾期至少19件，本组截止均早于H，实际恰19件。因此这19件逾期在该一盘合同中无法仅靠合法同序路由消除。预测成本距乐观下界仍19010.896秒，约实际成本4.5898%；下界可能不可达到，不能把差值全当可学空间，更不能外推多盘/完整母流不可行。九项下界反例回归通过，该松弛属于强诊断而非方法创新。

## 强参考与创新反证

R1 的 `regional_native_002` 在005实跑6种请求链，包含非慢层时刻、执行前缀、迟到、过期、权限拒绝及已通知故障绕行。三动作真实 fork 产生两种实际路径，但 Storage 释放余量吸收了0.2秒差异，业务 headroom=0。这个实际余量反例不是新求解算法。

R2 的9×2合成组支持自动预测意图与消息提前期作用，但普通解析已解释其收益。双向耦合组 `coupled_native_003` 显示：载盘路由改变释放；空盘共享节点占用又改变 B2 下一跳。普通预测将总耗时20.61降至19.55，却让B2从11.75变成12.05，故保护门失败。B2在6.2才到达，先前不允许偷看它来安排返盘。

独立的已知服务合同组让B2于0.5真实出现并加载5.8秒，保持其首跳约6.35；合法预测消息明确传播条件占用。`known_service_native_001` 的反应/普通预测/公开窗口预测成本为26.31/25.25/26.10。窗口组保留B1/B2完成时间，仅让B3从10.01提前至9.80；同信息十动作真实有限参考中5个通过逐件保护，强窗口基线 headroom=0。该0.21秒属于普通强基线解释，未晋升 C2 创新。

最新判定与原始文献访问回执见 `NOVELTY_LEDGER.md`：C0工程范围扩大；C1仍为研究假设；C2需要具体机制重构与更多强对照；C3未放行大训练。通用分层、消息接口、更多测试、普通匹配和余量检查不计论文创新。

完整性漏洞修正后，006重新实际运行 `analytic_native_009`、`known_service_native_003`、`coupled_native_005`、`forecast_lifecycle_native_003`、`regional_native_003`，全部source_changed=[]。强窗口26.10、保护反例及有限域headroom=0重现。原版本回执保留，但其参考入口存在已复现的误认证缺陷，不能仅靠旧通过来认证其他删失分支。

进一步独立复核还发现显式 `envelope.status=null` 被当作无包装，已保留反例并修复；最终 `analytic_native_010`、`known_service_native_004` 再次实跑正常结果不变，独立29组完整性检查全部通过。最终参考源码 SHA256 为 `3be0198c943d4c2eb520ef258e270146dfafe9709d360d13b67551e86616efe1`。审查细节见 `ANALYTIC_INDEPENDENT_REVIEW.md`，含未重跑而仅读取的证据边界。

`regional_original_001` 把真实按需请求接至原图：双方共同增加明确的研究路线权限因子（不是现场授权），按公开观察选择第一个载盘未入边且有两个合法后缀的事件边界。8888.531299秒在国际owner看到选择[2,28]，A*请求经真实消息完成updated，父checkpoint不变。两支从同一后续控制相位推进至86400，均24件完成、19件逾期、逐袋成本相同；这一原图无收益结果保留。

原图强参考已扩到实际两个事前边界。`regional_original_003` 枚举上述时刻的WAIT、next2、next28，三支均全H完成且经独立审计，产生两种真实物理轨迹，逐袋成本相等。`p4_original_first_return_reference_006_001` 在首个固定60秒tick公开空盘意图（19800秒）枚举WAIT/解析/+1/+15/+30/+60秒六动作，六支全H完成，五种物理轨迹。解析与+1秒并列最佳；其余逐袋保护不通过。两小域headroom=0，仅约束该边界、单次干预及固定继续策略，**不能说明提前预测、多次干预、其他端口或全流量没有改进空间**。首返供入口替换整个当前epoch，缓存与下次tick相同，并非任意连续控制的全域优化。

`regional_original_001/002` 的选择清单误保留了加授权前的base输入hash，实际input文件和事件未伪造或覆盖；003已分别保存base与最终输入hash并完整重跑，独立复算一致。首返供001仍绑定null补丁前的参考版本，实际每支status均明确reached，经最终完成性规则逐项复核通过，未冒称已绑定最终源码。

## 100ms 与后续接入

`regional_native_002` 测量从观察、转换、A*、编解码、提交，到真实消息事件/owner复验、确认与响应编解码，并把其间 native 事件计算也计入。6个小图样本为0.102–0.425ms。它是完整单进程小样本链的测量，不是原图、部署或硬实时验收，也未包含外部控制器跨tick自动继续。

完整原图第一次反应控制已观察最大818.2ms；同H预测组也有138.65/123.15ms，均明确未过100ms。正在依据分项 profile 优化需求投影和解析候选计算，拒绝、超时和无候选保留分母。不能仅报告 native 事件或网络前向时间。

原图cProfile优化前后全部28506条业务结果逐字段一致，事件审计通过。候选计算1.648→0.552秒，路径查询34906→1603次，匹配0.276→0.009秒；同时改变native需求投影和Python实现，因此不作单因素归因。带剖析器的峰值315.78→76.72ms只作诊断。原图R1上述完整单请求样本实测1.7575ms，CPU计时落入当前计时分辨率0；不能据此声称全天或所有请求100ms达标。

最终006四组同H21600、每组50次owner调用，1×反应/预测峰值34.791/41.117ms，2×31.684/64.992ms，业务与物理事件逐字段与优化前相同，完整分母不变。005目录中一次名为predictive却未传该flag的运行保留为重复反应组，按真实回执标记排除，不按目录名认定策略。

随后针对原来76500秒热点追加**唯一一组固定预算全天验收** `p2_original_1x_reactive_H86400_006_001`，实际72.142秒到H86400，28506全观察、18装载、0完成，物理审计通过。相同国际owner、相同27975公开需求/零供给热点从818.200降至136.725ms，仍超限。全日最大是83700秒国内owner的211.262ms（观察87.080＋解析124.178），194次中75次>100ms。因此 **100ms当前明确未达标，连已测owner子链都失败**。6小时样本峰值不能代替全天。完整请求还有未计的发布编解码、交付复验/确认等开销，不能通过改变统计对象或P99门槛放行。

后续实际接入点：完成最新源码的大流重测；保留全流阻塞合同，继续合法原图往返研究组；将服务预测修订/撤销与固定模块用盘次序接入真实修复候选，比较同权限解析、通用资源闭合和全域修复。只有候选覆盖、信息、标签与 P5 方法门成立后再进入 P6。P7的完整运营外推、独立来源、真实模块/无等待链/off-carrier、显式隔离与全链100ms仍有缺口，未因工程进展而降级。

当前具体续研顺序：先用只读原生索引及FIFO等价列设计紧凑控制投影，和全量观察逐动作/逐业务/逐事件对照，不删除offered分母或当前需求，也不缩K伪造低延迟；再按P5分支C检查服务约束/需求变动/长线条件下联合候选的剩余空间，固定强窗口与同信息参考，明确资源/源保护/策略读集边界。当前零headroom只来自受限首动作域，不能作为停止R1/R2或开始弱标签大训练的理由。

主要复跑命令（在本独立工作区执行，使用新的output目录）：

```powershell
$env:PYTHONPATH='src;.'
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'
$env:PYTHONIOENCODING='utf-8'
$g31Binary='build_lt_session_006/python/czr005_circulation.cp311-win_amd64.pyd'
& C:/PROGRAMING/python3.11.9/python.exe -m scripts.experiments.g31_ics_circulation.validate_live --binary $g31Binary --build-receipt outputs/experiments/g31_ics_long_term_20261013/p1_build_006/receipt.json --output outputs/experiments/g31_ics_long_term_20261013/live_validation_reproduce_001
& C:/PROGRAMING/python3.11.9/python.exe -m scripts.experiments.g31_ics_circulation.validate_original_regional --binary $g31Binary --reference --output outputs/experiments/g31_ics_long_term_20261013/regional_original_reproduce_001
& C:/PROGRAMING/python3.11.9/python.exe -m scripts.experiments.g31_ics_circulation.validate_original_reference --binary $g31Binary --output outputs/experiments/g31_ics_long_term_20261013/original_reference_reproduce_001
& C:/PROGRAMING/python3.11.9/python.exe -m scripts.experiments.g31_ics_circulation.run_original_control --binary $g31Binary --scale 1 --horizon 86400 --control-period 900 --max-events 100000 --wall-budget 120 --output outputs/experiments/g31_ics_long_term_20261013/original_day_reproduce_001
```

精确续跑状态、命令与最新回执以 `RESEARCH_STATE.json` 为准；所有 runner 都要求新的输出目录，不能覆盖历史。

最终冻结复核：`live_validation_005` 为196项通过、0失败/错误/跳过，source_changed=[]，二进制与build006身份一致。004虽196项测试均过，但下界脚本在运行中改动，完整性门正确拒绝发布；失败回执保留，未冒用其测试计数作为最终通过。
